import { HiOutlineX } from "react-icons/hi";
import { useContext } from "react";
import { IAppContext } from "../store/AppContext";
import {
    Switch,
    Route,
    RouteComponentProps,
    useHistory,
    useRouteMatch,
} from "react-router-dom";
import AppContext from "../store/AppContext";
import AbaOcorrenciasContainer from "../components/menu-sidebar-components/AbaOcorrenciasContainer";
import ConfiguracoesContainer from "../components/menu-sidebar-components/configuracoes/Configuracoes";
import ControleHelperContainer from "../components/menu-sidebar-components/ControleHelper";
import GerenciadorAudiosContainer from "../components/menu-sidebar-components/gerenciador-audios/GerenciadorAudios";
import NotificacoesContainer from "../components/menu-sidebar-components/Notificacoes";
import PerfilContainer from "../components/menu-sidebar-components/PerfilContainer";
import { IiconsStates } from "../ts/interfaces";

const MenuSidebarContainer = ({ iconsStates, isLoading, occurrences }: any) => {
    const history: RouteComponentProps["history"] = useHistory();
    const match: RouteComponentProps["match"] = useRouteMatch();
    const { closeMenuSidebar, isMenuOpen }: IAppContext =
        useContext(AppContext);

    const closeMenuSidebarHandler = (
        closeMenuSidebar: IAppContext["closeMenuSidebar"]
    ): void => {
        closeMenuSidebar();
        history.push("/home");
        iconsStates.setIsIconHelperLogoOpen(false);
        iconsStates.setIsIconConfiguracoesOpen(false);
        iconsStates.setIsIconNotificacoesOpen(false);
        iconsStates.setIsIconOcorrenciasOpen(false);
        iconsStates.setIsIconControleHelperOpen(false);
        iconsStates.setIsIconGerenciadorAudioOpen(false);
    };

    return (
        <div
            className={`${
                isMenuOpen ? "" : "-translate-x-full"
            } absolute transition bg-white duration-300 z-19 ${
                match.url.slice(6, 19) === "configuracoes"
                    ? "w-full"
                    : "w-45% 2xl:w-1/3"
            } h-screen transform`}
        >
            <HiOutlineX
                onClick={closeMenuSidebarHandler.bind(null, closeMenuSidebar)}
                className="absolute w-8 h-8 text-gray-700 cursor-pointer top-6 right-6"
            />

            <Switch>
                <Route exact path={`/home/perfil-container`}>
                    <PerfilContainer />
                </Route>
                <Route exact path={`/home/ocorrencias/:p2?`}>
                    <AbaOcorrenciasContainer />
                </Route>
                <Route exact path={`/home/controle-helper`}>
                    <ControleHelperContainer />
                </Route>
                <Route exact path={`/home/gerenciador-audios/:p2?`}>
                    <GerenciadorAudiosContainer />
                </Route>
                <Route exact path={`/home/notificacoes`}>
                    <NotificacoesContainer
                        isLoading={isLoading}
                        occurrences={occurrences}
                    />
                </Route>
                <Route exact path={`/home/configuracoes/:p2?/:p3?`}>
                    <ConfiguracoesContainer />
                </Route>
            </Switch>
        </div>
    );
};

export default MenuSidebarContainer;
