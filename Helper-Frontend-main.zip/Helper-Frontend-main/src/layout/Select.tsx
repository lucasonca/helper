const Select = ({
    label,
    name,
    touched,
    error,
    handleBlur,
    handleChange,
    value,
    options,
    question,
}: any) => {
    return (
        <div className="flex flex-col flex-1 gap-2 text-sm">
            <label className="font-semibold">{label}</label>
            <select
                className="text-gray-600 text-xs px-2.5 py-2 rounded outline-none cursor-pointer bg-greyish"
                style={{ cursor: "pointer" }}
                onBlur={handleBlur}
                value={value}
                name={name}
                onChange={handleChange}
            >
                <option value="">{question}</option>
                {options.map((option: any, id: any) => {
                    return (
                        <option
                            value={option.id}
                            key={option.length > 0 ? option.id : id}
                        >
                            {option.name}
                        </option>
                    );
                })}
            </select>
            {touched && error && (
                <span style={{ color: "red", fontSize: "12px" }}>{error}</span>
            )}
        </div>
    );
};

export default Select;
