interface IBlackButtonProps {
    children: string | JSX.Element;
    onClick?: () => void;
    style?: string;
}

const BlackButton = ({ children, onClick, style }: IBlackButtonProps) => (
    <button
        type="submit"
        onClick={onClick}
        className={`${style} self-end px-4 py-2 text-xs text-white rounded outline-none bg-custom-black`}
    >
        {children}
    </button>
);

export default BlackButton;
