interface INotificationWrapperProps {
    number: number;
    children: JSX.Element;
}

const NotificationWrapper = (props: INotificationWrapperProps) => (
    <div className="relative">
        <div className="absolute grid w-4 h-4 text-xs text-white rounded-full bg-red -right-2 -top-2 place-items-center">
            {props.number}
        </div>
        {props.children}
    </div>
);

export default NotificationWrapper;
