const InputText = ({
    label,
    name,
    touched,
    error,
    handleBlur,
    handleChange,
    value,
    style,
}: any) => {
    return (
        <div style={style} className="flex flex-col flex-1 gap-2 text-sm">
            <label
                className="font-semibold"
                style={{ cursor: "pointer" }}
                htmlFor={name}
            >
                {label}
            </label>
            <input
                placeholder={label}
                className={`text-gray-600 text-xs px-2.5 py-2 rounded outline-none bg-greyish`}
                onBlur={handleBlur}
                onChange={handleChange}
                type="text"
                id={name}
                value={value}
                name={name}
            />
            {touched && error && (
                <span style={{ color: "red", fontSize: "12px" }}>{error}</span>
            )}
        </div>
    );
};

export default InputText;
