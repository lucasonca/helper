import { NavLink } from "react-router-dom";

import { styleCSS, classes } from "../constants/consts";

interface IButtonsSwitchProps {
    urls: Array<Iurls>;
}

export interface Iurls {
    text: string;
    url: string;
    id: number;
}

const ButtonsSwitch = ({ urls }: IButtonsSwitchProps) => (
    <div className="grid px-4 py-3 text-white rounded place-items-center bg-greyish">
        <ul className="flex items-center gap-6">
            {urls.map((url) => (
                <li key={url.id}>
                    <NavLink
                        className={classes}
                        to={url.url}
                        activeStyle={styleCSS}
                    >
                        {url.text}
                    </NavLink>
                </li>
            ))}
        </ul>
    </div>
);

export default ButtonsSwitch;
