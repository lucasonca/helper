interface IWeirdShapeIcons {
    children: JSX.Element;
    isIconOpen: boolean;
}

const WeirdShapeIcons = ({ children, isIconOpen }: IWeirdShapeIcons) => (
    <span
        className={`${
            !isIconOpen ? "overflow-hidden" : ""
        } relative grid w-full h-11 2xl:h-14 place-items-center bg-custom-black`}
    >
        {children}
        <span
            className={`${
                !isIconOpen ? "" : "bg-custom-black"
            } absolute z-10 block w-full rounded-tr-xl -bottom-11 h-11 2xl:h-14`}
        ></span>
        <span
            className={`${
                !isIconOpen ? "bg-custom-black" : "bg-white"
            } absolute block w-full -bottom-11 h-11 2xl:h-14`}
        ></span>
        <span
            className={`${
                !isIconOpen ? "bg-custom-black" : "bg-white"
            } absolute bottom-0 block w-full rounded-tl-full rounded-bl-full h-11 2xl:h-14`}
        ></span>
        <span
            className={`${
                !isIconOpen ? "" : "bg-custom-black"
            } absolute z-10 block w-full rounded-br-xl -top-11 h-11 2xl:h-14`}
        ></span>
        <span
            className={`${
                !isIconOpen ? "bg-custom-black" : "bg-white"
            } absolute block w-full -top-11 h-11 2xl:h-14`}
        ></span>
    </span>
);

export default WeirdShapeIcons;
