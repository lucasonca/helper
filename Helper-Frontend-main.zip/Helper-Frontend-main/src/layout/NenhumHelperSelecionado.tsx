import { AiOutlineExclamationCircle } from "react-icons/ai";

const NenhumHelperSelecionado = () => (
    <div className="grid flex-grow place-items-center">
        <div className="flex items-center gap-3 px-6 py-3 text-gray-500 border border-gray-500 border-dashed rounded-md">
            <AiOutlineExclamationCircle className="w-6 h-6" />
            <h1>Nenhum Helper Selecionado</h1>
        </div>
    </div>
);

export default NenhumHelperSelecionado;
