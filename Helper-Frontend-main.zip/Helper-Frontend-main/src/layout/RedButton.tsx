interface IRedButtonProps {
    children: string | JSX.Element;
    onClick?: () => void;
    style?: string;
}

const RedButton = ({ children, style, onClick }: IRedButtonProps) => (
    <button
        onClick={onClick}
        className={`${style} px-4 py-2 text-xs text-white rounded outline-none bg-red`}
        type="submit"
    >
        {children}
    </button>
);

export default RedButton;
