const RadioButtons = ({
    name,
    touched,
    error,
    handleChange,
    value,
    options,
    question,
}: any) => {
    return (
        <div className="flex flex-col w-full">
            <div className="flex items-center justify-between w-full">
                <label className="flex-grow w-full">{question}</label>
                {options.map(({ text, id }: any) => {
                    return (
                        <div className="flex items-center gap-x-1" key={id}>
                            <input
                                style={{ cursor: "pointer" }}
                                name={name}
                                type="radio"
                                id={text}
                                value={text}
                                checked={value === text}
                                onChange={handleChange}
                            />
                            <label
                                style={{
                                    cursor: "pointer",
                                    marginRight: "16px",
                                }}
                                htmlFor={text}
                            >
                                {text}
                            </label>
                        </div>
                    );
                })}
            </div>
            {touched && error && (
                <span style={{ color: "red", fontSize: "12px" }}>{error}</span>
            )}
        </div>
    );
};

export default RadioButtons;
