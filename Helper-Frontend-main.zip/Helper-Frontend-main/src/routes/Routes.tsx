import {
    BrowserRouter as Router,
    Switch,
    Route,
    Redirect,
} from "react-router-dom";
import LoginPage from "../screens/LoginPage";
import HomeContainer from "../screens/HomeContainer";
import { useContext } from "react";
import AppContext from "../store/AppContext";

const Routes = () => {
    const { currentUser }: any = useContext(AppContext);

    return (
        <Router>
            {currentUser ? (
                <Switch>
                    <Route
                        path="/home/:p1?/:p2?/:p3?"
                        exact
                        component={HomeContainer}
                    />
                    <Route path="*" render={() => <Redirect to="/home" />} />
                    <Route
                        path="*"
                        render={() => (
                            <p className="grid h-screen place-items-center">
                                Página não encontrada!
                            </p>
                        )}
                    />
                </Switch>
            ) : (
                <Switch>
                    <Route path="/login" component={LoginPage} />
                    <Route
                        exact
                        path="*"
                        render={() => <Redirect to="/login" />}
                    />
                </Switch>
            )}
        </Router>
    );
};

export default Routes;
