import { useRef, useEffect } from "react";
import { loadModules } from "esri-loader";

// hooks allow us to create a map component as a function
const MapView = () => {
    // create a ref to element to be used as the map's container
    const mapEl: any = useRef(null);

    // use a side effect to create the map after react has rendered the DOM
    useEffect(() => {
        // define the view here so it can be referenced in the clean up function
        let view: any;

        // the following code is based on this sample:
        // https://developers.arcgis.com/javascript/latest/sample-code/webmap-basic/index.html
        // first lazy-load the esri classes
        loadModules(["esri/Map", "esri/views/MapView"], { css: true }).then(
            ([Map, MapView]) => {
                const map = new Map({
                    basemap: "gray-vector",
                });

                // and we show that map in a container
                view = new MapView({
                    map: map,

                    // use the ref as a container
                    container: mapEl.current,
                    zoom: 10,
                    center: [-49.27306, -25.42778], // longitude, latitude [Curitiba]
                });
            }
        );

        return () => {
            // clean up the map view
            if (!!view) {
                view.destroy();
                view = null;
            }
        };
    }, []);

    return (
        <div className="absolute inset-y-0 right-0 z-4 left-16" ref={mapEl} />
    );
};

export default MapView;
