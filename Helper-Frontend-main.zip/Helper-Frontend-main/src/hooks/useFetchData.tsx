import ContractServices from "../services/contract-services";
import GroupServices from "../services/group-services";
import UserServices from "../services/user-services";
import HelperServices from "../services/helper-services";
import InstituicaoServices from "../services/instituicao-services";
import RoleServices from "../services/role-services";
import ClassificationServices from "../services/classification-services";
import { useState, useEffect } from "react";
import NatureServices from "../services/nature-services";

const classificationServices = new ClassificationServices("classifications");
const natureServices = new NatureServices("natures");
const roleServices = new RoleServices("roles");
const instituicaoServices = new InstituicaoServices("institutions");
const helperServices = new HelperServices("helpers");
const userServices = new UserServices("users");
const groupServices = new GroupServices("groups");
const contractServices = new ContractServices("contracts");
const useFetchInitialData = () => {
    const [natures, setNatures] = useState<Array<any>>([]);
    const [contratos, setContracts] = useState<Array<any>>([]);
    const [grupos, setGroups] = useState<Array<any>>([]);
    const [users, setUsers] = useState<Array<any>>([]);
    const [helpers, setHelpers] = useState<Array<any>>([]);
    const [classifications, setClassifications] = useState<Array<any>>([]);
    const [instituicoes, setInstituicoes] = useState<Array<any>>([]);
    const [roles, setRoles] = useState<Array<any>>([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        setIsLoading(true);

        const timer = setTimeout(() => {
            classificationServices
                .readAll()
                .then((data) => setClassifications(data));
            natureServices.readAll().then((data) => setNatures(data));
            roleServices.readAll().then((data) => setRoles(data));
            instituicaoServices.readAll().then((data) => setInstituicoes(data));
            helperServices.readAll().then((data) => setHelpers(data));
            contractServices.readAll().then((data) => setContracts(data));
            groupServices.readAll().then((data) => setGroups(data));

            userServices.readAll().then((data) => {
                setUsers(data);
                setIsLoading(false);
            });
        }, 1000);

        return () => clearTimeout(timer);
    }, []);

    function natureFromClassification(classifications: any, id: any) {
        const listOfNatures = [];
        return listOfNatures.push(classifications[id]);
    }

    return {
        contratos,
        grupos,
        users,
        setUsers,
        isLoading,
        helpers,
        instituicoes,
        roles,
        natures,
        classifications,
        natureFromClassification,
        setNatures,
        setClassifications,
    };
};

export default useFetchInitialData;
