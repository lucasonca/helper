import { useState } from "react";

import { v4 as uuidv4 } from "uuid";

export interface IInputFromUser {
    id: string;
    text: string;
}

export const useForm = () => {
    const [arraySearchField, setArraySearchField] = useState<IInputFromUser[]>(
        []
    );
    const [inputUser, setInputUser] = useState<string>("");

    const inputChangeHandler = (e: any): void => {
        setInputUser(e.target.value);
    };

    const submitInputFieldHandler = (e: any): void => {
        e.preventDefault();
        const newInput: IInputFromUser = {
            id: uuidv4(),
            text: inputUser,
        };
        setArraySearchField((prev) => [...prev, newInput]);
        resetField();
    };

    const resetField = (): void => {
        setInputUser("");
    };

    const deleteInputSearch = (id: string) => {
        const newArray: Array<IInputFromUser> = [...arraySearchField].filter(
            (item) => item.id !== id
        );
        setArraySearchField(newArray);
    };

    return {
        arraySearchField,
        inputUser,
        inputChangeHandler,
        deleteInputSearch,
        submitInputFieldHandler,
    };
};
