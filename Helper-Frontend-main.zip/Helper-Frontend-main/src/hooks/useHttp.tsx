import { useState, useEffect, useMemo } from "react";
import UserServices from "../services/user-services";
import { Contrato, Classificacao, Grupo } from "../ts/interfaces";
import * as yup from "yup";
import { useFormik } from "formik";
import { name as nameYup } from "../validation/yup";

const initialState = { name: "" };

const useHttpCampos = (endpoint: string) => {
    const memoizedMasterServiceClassInstance = useMemo(
        () => new UserServices(endpoint),
        [endpoint]
    );
    const [isLoading, setIsLoading] = useState(false);
    const [data, setData] = useState<
        Array<Contrato | Classificacao | Grupo | any>
    >([]);

    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: initialState,

            onSubmit: ({ name }, { resetForm }) =>
                formSubmittedHandler(resetForm, name),

            validationSchema: yup.object({
                name: nameYup,
            }),
        });

    useEffect(() => {
        setIsLoading(true);

        const timer = setTimeout(() => {
            memoizedMasterServiceClassInstance.readAll().then((d) => {
                setData((prev) => [...Array.from(d), ...prev]);
                setIsLoading(false);
            });
        }, 1000);

        return () => clearTimeout(timer);
    }, [memoizedMasterServiceClassInstance]);

    const formSubmittedHandler = async (resetForm: any, name: string) => {
        await memoizedMasterServiceClassInstance
            .create({ name: name })
            .then((data) => setData((prev) => prev.concat(data.data.new_data)));

        resetForm();
    };

    return {
        handleSubmit,
        data,
        handleChange,
        handleBlur,
        values,
        errors,
        touched,
        isLoading,
    };
};

export default useHttpCampos;
