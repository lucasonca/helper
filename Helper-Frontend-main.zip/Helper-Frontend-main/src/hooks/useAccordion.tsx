import { useState, MutableRefObject, useRef, useEffect } from "react";

export const useAccordion = () => {
    const [active, setActive] = useState<boolean>(false);
    const contentRef: MutableRefObject<HTMLDivElement | any> = useRef(null);

    useEffect(() => {
        contentRef.current.style.display = active ? `block` : "none";
        return () => {};
    }, [contentRef, active]);

    const toggleActive = () => {
        setActive((prev) => !prev);
    };

    return { active, contentRef, toggleActive };
};
