import { useState } from "react";

const usePagination = (users: any) => {
    const [pageNumber, setPageNumber] = useState(0);

    const usersPerPage = 8;
    const pagesVisited = pageNumber * usersPerPage;

    const pageCount = Math.ceil(users.length / usersPerPage);

    const changePage = ({ selected }: any) => {
        setPageNumber(selected);
    };

    return { pagesVisited, pageCount, usersPerPage, changePage };
};

export default usePagination;
