import axios from "axios";

export default class ApiServices {
    api_hostname: string;

    constructor() {
        this.api_hostname = "http://localhost:3002";
    }

    protected GETData(endpoint: string, payload: any = "", token: any = false) {
        let url = `${this.api_hostname}/${endpoint}`;
        if (payload !== "") url = `${url}/${payload}`;

        return new Promise((resolve, reject) => {
            axios({
                method: "GET",
                url: url,
                headers: {
                    authorization: `Bearer ${token}`,
                },
            })
                .then((response) => {
                    resolve(response);
                })
                .catch((err) => {
                    alert(err.response?.data.message);
                });
        });
    }

    protected POSTData(
        data: any,
        endpoint: string,
        payload: any = "",
        token: any = false
    ) {
        // console.log(payload);
        let url = `${this.api_hostname}/${endpoint}`;
        if (payload !== "") url = `${url}/${payload}`;

        return new Promise((resolve, reject) => {
            axios({
                method: "POST",
                url: url,
                data: data,
                headers: {
                    authorization: `Bearer ${token}`,
                },
            })
                .then((response) => {
                    resolve(response);
                })
                .catch((err) => alert(err.response?.data.message));
        });
    }

    protected PUTData(
        data: any,
        endpoint: string,
        payload: any,
        token: any = false
    ) {
        let url = `${this.api_hostname}/${endpoint}`;
        url = `${url}/${payload}`;
        return new Promise((resolve, reject) => {
            axios({
                method: "PUT",
                url: url,
                data: data,
                headers: {
                    authorization: `Bearer ${token}`,
                },
            })
                .then((response) => {
                    resolve(response);
                })
                .catch((err) => alert(err.response?.data.message));
        });
    }

    protected PATCHData(
        data: any,
        endpoint: string,
        payload: any = "",
        token: any = false
    ) {
        let url = `${this.api_hostname}/${endpoint}`;
        if (payload !== "") url = `${url}/${payload}`;
        return new Promise((resolve, reject) => {
            axios({
                method: "PATCH",
                url: url,
                data: data,
                headers: {
                    authorization: `Bearer ${token}`,
                },
            })
                .then((response) => {
                    resolve(response);
                })
                .catch((err) => alert(err.response?.data.message));
        });
    }

    protected DELETEData(endpoint: string, payload: any, token: any = false) {
        let url = `${this.api_hostname}/${endpoint}`;
        url = `${url}/${payload}`;

        return new Promise((resolve, reject) => {
            axios({
                method: "DELETE",
                url: url,
                headers: {
                    authorization: `Bearer ${token}`,
                },
            })
                .then((response) => {
                    resolve(response);
                })
                .catch((err) => alert(err.response?.data.message));
        });
    }
}
