import MasterServices from "./master-services"

export default class RoleServices extends MasterServices {
  constructor(role_endpoint: string) {
    super(role_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

