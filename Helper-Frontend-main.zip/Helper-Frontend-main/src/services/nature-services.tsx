import MasterServices from "./master-services"

export default class NatureServices extends MasterServices {
  constructor(nature_endpoint: string) {
    super(nature_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

