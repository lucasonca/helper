import MasterServices from "./master-services"

export default class ContractServices extends MasterServices {
  constructor(contract_endpoint: string) {
    super(contract_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

