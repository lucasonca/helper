import MasterServices from "./master-services"

export default class OccurrenceServices extends MasterServices {
  constructor(occurrence_endpoint: string) {
    super(occurrence_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

