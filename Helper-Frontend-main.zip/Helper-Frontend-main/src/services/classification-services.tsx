import MasterServices from "./master-services";

export default class ClassificationServices extends MasterServices {
    // constructor(classification_endpoint: string) {
    //   super(classification_endpoint)
    //   * Eg.: super("products")
    //   * It means: /products
    //   * Eg.: http://localhost:3000/products
    // }
}
