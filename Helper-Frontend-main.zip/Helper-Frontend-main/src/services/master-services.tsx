import TokenStorageCookie from "../token/token-storage-cookie";
import ApiServices from "./api-services";

export default class MasterServices extends ApiServices {
    endpoint_prefix: string;
    token: any;
    protected login_type: string;
    constructor(endpoint_prefix: string) {
        super();
        this.endpoint_prefix = endpoint_prefix;
        const token_storage = new TokenStorageCookie();
        this.token = token_storage.getCookieToken() ?? false;
        this.login_type = "";
    }

    async readAll(): Promise<any> {
        const response: any = await this.GETData(
            this.endpoint_prefix,
            this.token.token
        );
        return response.data;
    }

    async readOne(ID: any): Promise<any> {
        const response: any = await this.GETData(this.endpoint_prefix, ID);
        return response.data;
    }

    async create(data: any): Promise<any> {
        const response = await this.POSTData(data, this.endpoint_prefix);
        return response;
    }

    async update(data: any, ID: any): Promise<any> {
        const response = await this.PUTData(data, this.endpoint_prefix, ID);
        return response;
    }

    async delete(ID: number): Promise<any> {
        const response = await this.DELETEData(this.endpoint_prefix, ID);
        return response;
    }

    async login(data: any): Promise<any> {
        let cookies_handle = new TokenStorageCookie();
        const response: any = await this.POSTData(
            data,
            `${this.endpoint_prefix}/login`
        );
        if (response?.data.auth) {
            cookies_handle.deleteToken();
            cookies_handle.storageToken(
                {
                    token: response.data.token,
                    user: response.data.user,
                    tipo: response.data.tipo,
                },
                this.login_type
            );
        }

        return response;
    }

    async logout(): Promise<any> {
        const response = await this.GETData(this.endpoint_prefix);
        return response;
    }
}
