import MasterServices from "./master-services";

export default class InstituicaoServices extends MasterServices {
    constructor(instituicao_endpoint: string) {
        super(instituicao_endpoint);
        // * Eg.: super("products")
        // * It means: /products
        // * Eg.: http://localhost:3000/products
    }
}
