import MasterServices from "./master-services"

export default class GroupServices extends MasterServices {
  constructor(group_endpoint: string) {
    super(group_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

