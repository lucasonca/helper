import MasterServices from "./master-services"

export default class UserServices extends MasterServices {
  constructor(user_endpoint: string) {
    super(user_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

