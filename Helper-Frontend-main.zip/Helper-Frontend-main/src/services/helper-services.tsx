import MasterServices from "./master-services"

export default class HelperServices extends MasterServices {
  constructor(helper_endpoint: string) {
    super(helper_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

