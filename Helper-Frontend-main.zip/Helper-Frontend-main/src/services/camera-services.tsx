import MasterServices from "./master-services"

export default class CameraServices extends MasterServices {
  constructor(camera_endpoint: string) {
    super(camera_endpoint)
    // * Eg.: super("products") 
    // * It means: /products
    // * Eg.: http://localhost:3000/products 
  }
}

