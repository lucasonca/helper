import Cookies from "universal-cookie";

export default class TokenStorageCookie {
    cookies: any;
    constructor() {
        this.cookies = new Cookies();
    }

    storageToken(token: any, type: string) {
        console.log(token);
        this.cookies.set(`${type}_token`, token, { path: "/" });
    }

    deleteToken() {
        this.cookies.remove("user_token", { path: "/" });
    }

    getCookieToken() {
        return {
            user_token: this.cookies.get("user_token"),
        };
    }
}
