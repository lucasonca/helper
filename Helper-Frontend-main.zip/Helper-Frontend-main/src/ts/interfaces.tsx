import { SetStateAction, Dispatch } from "react";

export interface Contrato {
    id?: number;
    name: string;
    created_at?: Date;
    updated_at?: Date;
}

export interface Grupo {
    id?: number;
    name: string;
    created_at?: Date;
    updated_at?: Date;
}

export interface Classificacao {
    id?: number;
    name: string;
    created_at?: Date;
    updated_at?: Date;
}

export interface CreateUser {
    name: string;
    email: string;
    contact_number: string;
    password: string;
    status: string;
    contract_id: string;
    group_id: string;
    type_id: string;
    confirm_password: string;
}

export interface GetUsers {
    name: string;
    email: string;
    contact_number: string;
    password: string;
    status: string;
    contract_id: Contrato;
    group_id: Grupo;
    type_id: string;
    confirm_password: string;
}

export interface IiconsStates {
    isIconHelperLogoOpen: boolean;
    setIsIconHelperLogoOpen: Dispatch<SetStateAction<boolean>>;
    isIconOcorrenciasOpen: boolean;
    setIsIconOcorrenciasOpen: Dispatch<SetStateAction<boolean>>;
    isIconControleHelperOpen: boolean;
    setIsIconControleHelperOpen: Dispatch<SetStateAction<boolean>>;
    isIconGerenciadorAudioOpen: boolean;
    setIsIconGerenciadorAudioOpen: Dispatch<SetStateAction<boolean>>;
    isIconNotificacoesOpen: boolean;
    setIsIconNotificacoesOpen: Dispatch<SetStateAction<boolean>>;
    isIconConfiguracoesOpen: boolean;
    setIsIconConfiguracoesOpen: Dispatch<SetStateAction<boolean>>;
}
