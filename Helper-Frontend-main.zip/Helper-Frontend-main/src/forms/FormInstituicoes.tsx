import RedButton from "../layout/RedButton";
import InstituicaoServices from "../services/instituicao-services";
import Select from "../layout/Select";
import InputText from "../layout/InputText";
import { useFormik } from "formik";
import { validationSchemaFormInstitutions } from "../validation/yup";
import useFetchData from "../hooks/useFetchData";
import AddCameras from "../components/AddCameras";

import { useState } from "react";

const initialState = {
    contract_id: "",
    helper_id: "",
    type_id: "",
    name: "",
    street: "",
    responsible: "",
    latitude: "",
    longitude: "",
    contato: "",
    phone: "",

    district: "", // add nos input do usuario
    number: "", // add nos input do usuario
    zip_code: "", // add nos input do usuario
};

const instituicaoServices = new InstituicaoServices("institutions");
const FormInstituicoes = () => {
    const { helpers, contratos } = useFetchData();

    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: initialState,

            onSubmit: (values, { resetForm }) =>
                formSubmittedHandler(resetForm, values),

            validationSchema: validationSchemaFormInstitutions,
        });

    const [camerasList, setCamerasList] = useState<Array<any>>([]);

    const formSubmittedHandler = (resetForm: any, values: any) => {
        instituicaoServices
            .create({
                name: values.name, //
                street: values.street, // Rua
                responsible: values.responsible, // Reponsável
                type_id: +values.type_id, //
                contract_id: +values.contract_id, //

                latitude: +values.latitude, //duvida
                longitude: +values.longitude, //duvida

                contato: values.contato, // contato do responsavel
                phone: values.longitude, //telefone da instituição
                helper_id: 1, //

                zip_code: values.zip_code, // duvida
                district: values.district, // duvida
                number: values.number, // duvida
            })
            .then(() => resetForm());
    };

    return (
        <form
            onSubmit={handleSubmit}
            className="grid grid-cols-2 mt-10 gap-x-10 gap-y-5"
        >
            <InputText
                label="Nome"
                name="name"
                touched={touched.name}
                error={errors.name}
                handleBlur={handleBlur}
                handleChange={handleChange}
                value={values.name}
            />
            <div className="flex gap-2">
                <Select
                    label="Tipo"
                    name="type_id"
                    touched={touched.type_id}
                    error={errors.type_id}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.type_id}
                    options={[
                        { id: 1, name: "Escola" },
                        { id: 2, name: "Igreja" },
                        { id: 3, name: "Outros" },
                    ]}
                    question="Escolha o tipo"
                />

                <Select
                    label="Contrato"
                    name="contract_id"
                    touched={touched.contract_id}
                    error={errors.contract_id}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.contract_id}
                    options={contratos}
                    question="Escolha seu contrato"
                />
            </div>
            <InputText
                label="Rua"
                name="street"
                touched={touched.street}
                error={errors.street}
                handleBlur={handleBlur}
                handleChange={handleChange}
                value={values.street}
            />
            <div className="flex gap-2">
                <InputText
                    label="Latitude"
                    name="latitude"
                    touched={touched.latitude}
                    error={errors.latitude}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.latitude}
                />
                <InputText
                    label="Longitude"
                    name="longitude"
                    touched={touched.longitude}
                    error={errors.longitude}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.longitude}
                />
            </div>
            <InputText
                label="Responsável"
                name="responsible"
                touched={touched.responsible}
                error={errors.responsible}
                handleBlur={handleBlur}
                handleChange={handleChange}
                value={values.responsible}
            />
            <div className="flex gap-2">
                <InputText
                    label="Contato"
                    name="contato"
                    touched={touched.contato}
                    error={errors.contato}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.contato}
                />
                <InputText
                    label="Telefone"
                    name="phone"
                    touched={touched.phone}
                    error={errors.phone}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.phone}
                />
            </div>
            <Select
                label="Associar um Helper"
                name="helper_id"
                touched={touched.helper_id}
                error={errors.helper_id}
                handleBlur={handleBlur}
                handleChange={handleChange}
                value={values.helper_id}
                options={helpers}
                question="Escolha o helper"
            />
            <div></div>
            <hr className="mt-4 border border-gray-300" />
            <hr className="mt-4 border border-gray-300" />

            <AddCameras setCamerasList={setCamerasList} />

            <div className="flex items-center justify-end col-start-2 col-end-3 gap-6">
                <a className="text-xs text-gray-800" href="/">
                    Cancelar
                </a>
                <RedButton>Salvar</RedButton>
            </div>
            {/* <pre>{JSON.stringify(camerasList, null, 2)}</pre> */}
        </form>
    );
};

export default FormInstituicoes;
