import { useHistory } from "react-router-dom";
import { useContext } from "react";
import * as yup from "yup";
import AppContext from "../store/AppContext";
import { useFormik } from "formik";
import UserServices from "../services/user-services";
import RedButton from "../layout/RedButton";
import InputText from "../layout/InputText";
import { openIconControleHelper } from "../components/icons/openIconControleHelper";

const userServices = new UserServices("users");
const FormPerfilContainer = () => {
    const history = useHistory();
    const ctx: any = useContext(AppContext);

    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: {
                name: ctx.currentUser.name,
                email: ctx.currentUser.email,
                contact_number: ctx.currentUser.contact_number,
                password: "",
                current_password: "",
            },

            onSubmit: (values, { resetForm }) => {
                userServices
                    .update(
                        {
                            name: values.name,
                            email: values.email,
                            contact_number: values.contact_number,
                            password: values.password,
                        },
                        ctx.currentUser.id
                    )
                    .then((data) => {
                        userServices
                            .readOne(ctx.currentUser.id)
                            .then((data) => {
                                ctx.setCurrentUser(data);
                            });
                        openIconControleHelper(ctx.iconsStates);

                        history.push("/home/controle-helper");

                        resetForm();
                    });
            },

            validationSchema: yup.object({
                name: yup.string().required("Digite seu nome"),
                email: yup.string().required("Digite seu email"),
                contact_number: yup.string(),
                password: yup.string().required("Digite sua senha"),
                previous_password: yup.string(),
            }),
        });

    return (
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 px-3">
            <InputText
                label="Nome"
                name="name"
                touched={touched.name}
                error={errors.name}
                handleBlur={handleBlur}
                handleChange={handleChange}
                value={values.name}
            />

            <div className="flex gap-2">
                <InputText
                    label="Email"
                    name="email"
                    touched={touched.email}
                    error={errors.email}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.email}
                />
                <InputText
                    label="Telefone"
                    name="contact_number"
                    touched={touched.contact_number}
                    error={errors.contact_number}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.contact_number}
                />
            </div>

            <div className="flex gap-2">
                <div className="flex flex-col flex-grow gap-2">
                    <InputText
                        label="Senha Atual"
                        name="current_password"
                        touched={touched.current_password}
                        error={errors.current_password}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.current_password}
                    />
                </div>
                <div className="flex flex-col flex-grow gap-2">
                    <InputText
                        label="Nova Senha"
                        name="password"
                        touched={touched.password}
                        error={errors.password}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.password}
                    />
                </div>
            </div>

            <div className="flex flex-col mt-5">
                <RedButton>Salvar</RedButton>
            </div>
        </form>
    );
};

export default FormPerfilContainer;
