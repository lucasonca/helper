import * as yup from "yup";

import { useFormik } from "formik";
import RedButton from "../layout/RedButton";
import Select from "../layout/Select";
import InputText from "../layout/InputText";
import RadioButtons from "../layout/RadioButtons";
import { occurrences_validation } from "../validation/yup";
import useFetchInitialData from "../hooks/useFetchData";
import OccurrenceServices from "../services/occurrence-services";
import { useEffect } from "react";
import { useHistory } from "react-router-dom";

const initialState = {
    description: "",
    wounds_risk_death: null,
    local_author: null,
    armed_author: null,
    risk_tumult: null,
    requester_name: "",
    requester_telephone: "",
    location: "",
    forward: "", // bool
    blatant: "", // bool
    occurrence_number: "",
    // classification_id: "",
    // nature_id: "",

    // operator_id: "",
    // employee_id: "",
    // helper_id: "",
    // level: "",
    // type: "",
    // status: "",
};

const occurrenceServices = new OccurrenceServices("occurrences");
const FormEditarUmaOcorrencia = ({
    occurrenceToBeEdited,
    setOccurrenceToBeEdited,
}: any) => {
    const {
        classifications,
        natures,
        natureFromClassification,
        setNatures,
        setClassifications,
    } = useFetchInitialData();
    const history = useHistory();
    // const { isMessageVisible, toggleMessagesContainer }: IAppContext = useContext(AppContext)

    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: occurrenceToBeEdited,

            onSubmit: (values, { resetForm }) => {
                const newOccurrence = {
                    description: values.description,

                    //     level: "2", // Nível function

                    wounds_risk_death:
                        values.wounds_risk_death === "Sim"
                            ? 0
                            : values.wounds_risk_death === "Não"
                            ? 1
                            : 2,
                    local_author:
                        values.local_author === "Sim"
                            ? 0
                            : values.local_author === "Não"
                            ? 1
                            : 2,
                    armed_author:
                        values.armed_author === "Sim"
                            ? 0
                            : values.armed_author === "Não"
                            ? 1
                            : 2,
                    risk_tumult:
                        values.risk_tumult === "Sim"
                            ? 0
                            : values.risk_tumult === "Não"
                            ? 1
                            : 2,
                    classification_id: Number(values.classification_id),
                    // nature_id: 1,
                    location: values.location,
                    requester_name: values.requester_name,
                    requester_telephone: values.requester_telephone,
                    occurrence_number: values.occurrence_number,
                    forward: values.forward === "Sim" ? true : false,
                    blatant: values.blatant === "Sim" ? true : false,

                    //     operator_id: 10, // operador na base helper

                    //     helper_id: 1, // caso seja via totem

                    //     employee_id: 10, // caso seja via app
                    //     type: "policial", // Seria policial, bombeiro ou medico???  via app
                    status: 1, // 0: Pendente, 1: Em andamento, 2: Finalizado?
                };

                occurrenceServices
                    .update(newOccurrence, occurrenceToBeEdited.id)
                    .then((data) => {
                        history.push("/home/ocorrencias/em-andamento");
                    });

                console.log(values);
                resetForm();
            },

            validationSchema: yup.object(occurrences_validation),
        });

    const radioOptions = [
        { id: 0, text: "Sim" },
        { id: 1, text: "Não" },
        { id: 2, text: "Suspeita" },
    ];

    useEffect(() => {
        return () => {
            setNatures([]);
        };
    }, []);

    return (
        <form onSubmit={handleSubmit} className="w-full text-sm">
            {/* <div className="flex items-center justify-between mt-10">
                <h1 className="text-2xl font-semibold">Abrir uma Ocorrência</h1>
                {isMessageVisible && (
                    <BlackButton onClick={toggleMessagesContainer}>
                        <div className="flex items-center gap-2">
                            <span>Mensagens</span>
                            <AiOutlineEye />
                        </div>
                    </BlackButton>
                )}
                {!isMessageVisible && (
                    <RedButton onClick={toggleMessagesContainer}>
                        <div className="flex items-center gap-2">
                            <span>Mensagens</span>
                            <AiOutlineEyeInvisible />
                        </div>
                    </RedButton>
                )}
            </div> */}

            <div className="flex flex-col mt-6">
                <label className="font-semibold" htmlFor="desc">
                    Descrição
                </label>
                <textarea
                    name="description"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.description}
                    className="px-4 py-2 mt-4 text-xs rounded-md outline-none resize-none bg-greyish"
                    id="desc"
                    placeholder="Escreva uma Descrição"
                    rows={4}
                    cols={50}
                ></textarea>
                {touched.description && errors.description && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                        {errors.description}
                    </span>
                )}
            </div>

            <div className="flex flex-col my-7">
                <div className="flex items-center gap-2">
                    <h1 className="flex-shrink-0 font-semibold">
                        Nível de risco
                    </h1>
                    <span className="h-0.5 w-5/6 bg-yellow-400"></span>
                </div>

                <div className="flex mt-2 mb-4 text-gray-600">
                    <ul className="flex-grow mt-5 space-y-2 text-xs">
                        <li className="flex items-center justify-between">
                            <RadioButtons
                                name="wounds_risk_death"
                                touched={touched.wounds_risk_death}
                                error={errors.wounds_risk_death}
                                handleChange={handleChange}
                                value={values.wounds_risk_death}
                                options={radioOptions}
                                question="1 - Há pessoas feridas em risco de morte?"
                            />
                        </li>

                        <li className="flex items-center justify-between">
                            <RadioButtons
                                name="local_author"
                                touched={touched.local_author}
                                error={errors.local_author}
                                handleChange={handleChange}
                                value={values.local_author}
                                options={radioOptions}
                                question="2 - Autor do fato está no local?"
                            />
                        </li>

                        <li className="flex items-center justify-between">
                            <RadioButtons
                                name="armed_author"
                                touched={touched.armed_author}
                                error={errors.armed_author}
                                handleChange={handleChange}
                                value={values.armed_author}
                                options={radioOptions}
                                question="3 - Autor do fato está armado?"
                            />
                        </li>

                        <li className="flex items-center justify-between">
                            <RadioButtons
                                name="risk_tumult"
                                touched={touched.risk_tumult}
                                error={errors.risk_tumult}
                                handleChange={handleChange}
                                value={values.risk_tumult}
                                options={radioOptions}
                                question="4 - Há risco de tumulto no local?"
                            />
                        </li>
                    </ul>
                </div>

                <div className="flex justify-between gap-2 mb-4">
                    <Select
                        label="Classificação"
                        name="classification_id"
                        touched={touched.classification_id}
                        error={errors.classification_id}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.classification_id}
                        options={classifications}
                        question="Escolha a classificação"
                    />

                    {/* <Select
                        label="Natureza"
                        name="nature_id"
                        touched={touched.nature_id}
                        error={errors.nature_id}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.nature_id}
                        options={natures}
                        question="Escolha a natureza"
                    /> */}
                </div>

                <InputText
                    label="Localização"
                    name="location"
                    touched={touched.location}
                    error={errors.location}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.location}
                />

                <div className="flex justify-between gap-2 my-4">
                    <InputText
                        label="Solicitante"
                        name="requester_name"
                        touched={touched.requester_name}
                        error={errors.requester_name}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.requester_name}
                    />

                    <InputText
                        label="Telefone"
                        name="requester_telephone"
                        touched={touched.requester_telephone}
                        error={errors.requester_telephone}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.requester_telephone}
                    />
                </div>

                <InputText
                    label="Número do B.O."
                    name="occurrence_number"
                    touched={touched.occurrence_number}
                    error={errors.occurrence_number}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.occurrence_number}
                />

                <div className="flex flex-col items-center gap-2 mt-6 text-xs">
                    <RadioButtons
                        name="forward"
                        touched={touched.forward}
                        error={errors.forward}
                        handleChange={handleChange}
                        value={values.forward}
                        options={radioOptions.slice(0, 2)}
                        question="Encaminhamento?"
                    />
                    <RadioButtons
                        name="blatant"
                        touched={touched.blatant}
                        error={errors.blatant}
                        handleChange={handleChange}
                        value={values.blatant}
                        options={radioOptions.slice(0, 2)}
                        question="Flagrante?"
                    />
                </div>

                <div className="mt-10 text-center">
                    <RedButton>Editar Ocorrência</RedButton>
                </div>
            </div>
            {/* <pre>{JSON.stringify(values.classification_id, null, 2)}</pre>
            <pre>{JSON.stringify(classifications, null, 2)}</pre>
            <pre>
                {JSON.stringify(
                    natureFromClassification(
                        classifications,
                        values.classification_id
                    ),
                    null,
                    2
                )}
            </pre> */}
        </form>
    );
};

export default FormEditarUmaOcorrencia;
