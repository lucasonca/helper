import RedButton from "../layout/RedButton";
import UserServices from "../services/user-services";
import useFetchData from "../hooks/useFetchData";
import InputText from "../layout/InputText";
import Select from "../layout/Select";
import { useFormik } from "formik";
import * as yup from "yup";
import {
    name,
    phoneRegExp,
    contract_id,
    password,
    email,
} from "../validation/yup";

const initialState = {
    name: "",
    email: "",
    contract_id: "", // nao necessariamente havera para o user super
    contact_number: "",
    group_id: "", // nao necessariamente havera para o user super
    password: "",
    confirm_password: "",
    role_id: "",
};

const userServices = new UserServices("users");
const FormUsers = () => {
    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: initialState,

            onSubmit: (values, { resetForm }) => {
                formSubmittedHandler(resetForm, values);
            },

            validationSchema: yup.object({
                name: name,
                email: email,
                role_id: yup.string().required("Escolha sua função"),
                contract_id: contract_id,
                contact_number: yup
                    .string()
                    .matches(phoneRegExp, "Número de telefone inválido")
                    .required("Digite seu telefone"),
                group_id: yup.string().required("Escolha seu grupo"),
                password: password,
                confirm_password: yup
                    .string()
                    .min(6, "Mínimo 6 dígitos")
                    .required("Confirme sua senha"),
            }),
        });

    const { contratos, grupos, roles } = useFetchData();

    const formSubmittedHandler = (resetForm: any, values: any) => {
        userServices
            .create({
                contract_id: +values.contract_id, //
                group_id: +values.group_id,
                role_id: Number(values.role_id),
                name: values.name,
                email: values.email,
                contact_number: values.contact_number,
                password: values.password,
                confirm_password: values.confirm_password,
                status: true, //
            })
            .then((data) => {
                console.log(data);
                resetForm();
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="flex gap-10 mx-20 mt-10">
                <div className="flex-1 space-y-4">
                    <InputText
                        label="Nome"
                        name="name"
                        touched={touched.name}
                        error={errors.name}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.name}
                    />
                    <InputText
                        label="Email"
                        name="email"
                        touched={touched.email}
                        error={errors.email}
                        handleBlur={handleBlur}
                        handleChange={handleChange}
                        value={values.email}
                    />

                    <div className="flex justify-between gap-2">
                        <Select
                            label="Função"
                            name="role_id"
                            touched={touched.role_id}
                            error={errors.role_id}
                            handleBlur={handleBlur}
                            handleChange={handleChange}
                            value={values.role_id}
                            options={roles}
                            question="Escolha sua função"
                        />
                        <Select
                            label="Contrato"
                            name="contract_id"
                            touched={touched.contract_id}
                            error={errors.contract_id}
                            handleBlur={handleBlur}
                            handleChange={handleChange}
                            value={values.contract_id}
                            options={contratos}
                            question="Escolha seu contrato"
                        />
                    </div>
                </div>

                <div className="flex-1 space-y-4">
                    <div className="flex justify-between gap-2">
                        <InputText
                            label="Telefone"
                            name="contact_number"
                            touched={touched.contact_number}
                            error={errors.contact_number}
                            handleBlur={handleBlur}
                            handleChange={handleChange}
                            value={values.contact_number}
                        />

                        <Select
                            label="Grupo"
                            name="group_id"
                            touched={touched.group_id}
                            error={errors.group_id}
                            handleBlur={handleBlur}
                            handleChange={handleChange}
                            value={values.group_id}
                            options={grupos}
                            question="Escolha sua grupo"
                        />
                    </div>

                    <div className="flex justify-between gap-2">
                        <InputText
                            label="Senha"
                            name="password"
                            touched={touched.password}
                            error={errors.password}
                            handleBlur={handleBlur}
                            handleChange={handleChange}
                            value={values.password}
                        />
                        <InputText
                            label="Corfirmar Senha"
                            name="confirm_password"
                            touched={touched.confirm_password}
                            error={errors.confirm_password}
                            handleBlur={handleBlur}
                            handleChange={handleChange}
                            value={values.confirm_password}
                        />
                    </div>
                </div>
            </div>
            <div className="flex items-center justify-end gap-5 mx-20 mt-10 text-sm ">
                <a className="text-xs" href="/">
                    Cancelar
                </a>
                <RedButton>Salvar</RedButton>
            </div>
        </form>
    );
};

export default FormUsers;
