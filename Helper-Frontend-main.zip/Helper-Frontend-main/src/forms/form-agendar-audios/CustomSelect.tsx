interface ICustomSelectProps {
    title: string;
    option1: string;
    option2: string;
    option3: string;
    option4: string;
}

const CustomSelect = ({
    option1,
    option2,
    option3,
    option4,
    title,
}: ICustomSelectProps) => {
    return (
        <div className="flex flex-col w-full gap-2">
            <label className="" htmlFor="">
                {title}
            </label>
            <select
                className="w-full h-8 cursor-pointer px-2 py-0.5 border border-black rounded"
                name=""
                id=""
            >
                <option value={option1}>{option1}</option>
                <option value={option2}>{option2}</option>
                <option value={option3}>{option3}</option>
                <option value={option4}>{option4}</option>
            </select>
        </div>
    );
};

export default CustomSelect;
