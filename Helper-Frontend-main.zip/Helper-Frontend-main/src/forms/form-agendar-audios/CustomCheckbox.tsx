const CustomCheckbox = () => {
    return (
        <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-1">
                <input
                    type="checkbox"
                    name="frequencia"
                    value="todos-os-dias"
                />
                <label htmlFor="">Todos os dias</label>
            </div>

            <div className="flex items-center gap-1">
                <input type="checkbox" name="frequencia" value="semanal" />
                <label htmlFor="">Semanal</label>
            </div>

            <div className="flex items-center gap-1">
                <input
                    type="checkbox"
                    name="frequencia"
                    value="personalizado"
                />
                <label htmlFor="">Personalizado</label>
            </div>
        </div>
    );
};

export default CustomCheckbox;
