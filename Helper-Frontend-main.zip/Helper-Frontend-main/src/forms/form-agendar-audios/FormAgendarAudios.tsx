import CustomSelect from "./CustomSelect";
import CustomCheckbox from "./CustomCheckbox";
import CustomInput from "./CustomInput";
import RedButton from "../../layout/RedButton";

const FormAgendarAudios = () => {
    return (
        <form className="flex flex-col gap-6 pb-16">
            <CustomCheckbox />

            <CustomSelect
                title="Escolher Mensagem"
                option1="01_UTILIZE A FAIXA DE PEDESTRE.wav"
                option2="Value1"
                option3="Value2"
                option4="Value3"
            />

            <div className="flex w-full gap-7">
                <CustomInput placeholder="07:00" text="Tempo Inicial" />

                <CustomInput placeholder="22:00" text="Tempo Final" />
            </div>

            <div className="flex w-full gap-7">
                <CustomInput placeholder="60" text="Intervalo(minutos)" />

                <CustomSelect
                    title="Cor"
                    option1="Azul"
                    option2="Branco"
                    option3="Preto"
                    option4="Roxo"
                />
            </div>

            <div className="flex items-center justify-between w-full">
                <button className="px-4 py-2 text-xs text-white bg-gray-400 rounded">
                    Reproduzir Agora
                </button>
                <RedButton>Agendar</RedButton>
            </div>
        </form>
    );
};

export default FormAgendarAudios;
