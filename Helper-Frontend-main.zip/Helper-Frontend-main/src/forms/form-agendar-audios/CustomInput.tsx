import { AiOutlineClockCircle } from "react-icons/ai";

interface ICustomInputProps {
    text: string;
    placeholder: string;
}

const CustomInput = ({ text, placeholder }: ICustomInputProps) => {
    return (
        <div className="flex flex-col w-full gap-2">
            <label htmlFor="">{text}</label>
            <div className="relative">
                <AiOutlineClockCircle className="absolute transform -translate-y-1/2 left-2 top-1/2" />
                <input
                    type="text"
                    onChange={() => {}}
                    className="h-8 w-full py-0.5 border border-black rounded pl-8"
                    placeholder={placeholder}
                    name=""
                    id=""
                />
            </div>
        </div>
    );
};

export default CustomInput;
