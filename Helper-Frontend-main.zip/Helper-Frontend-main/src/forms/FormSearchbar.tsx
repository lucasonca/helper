import { AiOutlineSearch } from "react-icons/ai";

interface IFormSearchbarProps {
    className: string;
    placeholder: string;
    bg?: string;
    w: string;
    value?: string;
    onChange?: (e: any) => void;
    onSubmit?: (e: any) => void;
}

const FormSearchbar = (props: IFormSearchbarProps) => (
    <form onSubmit={props.onSubmit} className={props.className}>
        <input
            name="search"
            placeholder={props.placeholder}
            className={`${props.bg} px-3 py-2 text-xs rounded outline-none ${props.w}`}
            type="text"
            value={props.value}
            onChange={props.onChange}
        />
        <button type="submit">
            <AiOutlineSearch className="absolute h-6 p-1 text-white transform -translate-y-1/2 bg-black rounded cursor-pointer w-7 right-1 top-1/2" />
        </button>
    </form>
);

export default FormSearchbar;
