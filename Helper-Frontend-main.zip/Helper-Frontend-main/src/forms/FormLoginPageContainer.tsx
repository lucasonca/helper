import { AiOutlineLock, AiOutlineEye } from "react-icons/ai";
import { BiEnvelope } from "react-icons/bi";
import { useFormik } from "formik";
import { password, email } from "../validation/yup";
import UserServices from "../services/user-services";
import * as yup from "yup";
import { useContext } from "react";
import AppContext from "../store/AppContext";

const initialState = {
    email: "",
    password: "",
};

const userServices = new UserServices("users/login");
const FormLoginPageContainer = () => {
    const ctx = useContext(AppContext);

    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: initialState,

            onSubmit: (values, { resetForm }) => {
                userServices
                    .create({
                        email: values.email,
                        password: values.password,
                    })
                    .then((res) => {
                        const data = res?.data;
                        if (data.auth) {
                            ctx.loginHandler(data);
                            resetForm();
                        } else {
                            alert("Usuário ou senha incorretos!");
                        }
                    });
            },

            validationSchema: yup.object({
                email: email,
                password: password,
            }),
        });

    return (
        <div className="flex flex-col items-center justify-center w-full text-white border-l border-white lg:max-w-xl gap-7">
            <h1 className="text-4xl font-semibold">Login</h1>
            <form className="w-3/4 space-y-4" onSubmit={handleSubmit}>
                <div className="relative bg-white rounded">
                    <input
                        onBlur={handleBlur}
                        name="email"
                        placeholder="Email"
                        value={values.email}
                        onChange={handleChange}
                        className="w-3/4 py-2 ml-10 text-gray-800 rounded outline-none appearance-none"
                        type="email"
                    />
                    <BiEnvelope className="absolute transform -translate-y-1/2 left-2 top-1/2 text-red" />
                </div>
                {touched.email && errors.email && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                        {errors.email}
                    </span>
                )}

                <div className="relative bg-white rounded">
                    <AiOutlineLock className="absolute transform -translate-y-1/2 left-2 text-red top-1/2" />
                    <input
                        onBlur={handleBlur}
                        name="password"
                        placeholder="Password"
                        value={values.password}
                        onChange={handleChange}
                        className="w-3/4 py-2 ml-10 text-gray-800 rounded outline-none appearance-none"
                        type="password"
                    />
                    <AiOutlineEye className="absolute transform -translate-y-1/2 right-2 text-red top-1/2" />
                </div>
                {touched.password && errors.password && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                        {errors.password}
                    </span>
                )}

                <button
                    type="submit"
                    className="block w-full px-3 py-2 rounded outline-none bg-red"
                >
                    Entrar
                </button>

                <div className="flex justify-between">
                    <div className="inline-flex items-center gap-1">
                        <input type="checkbox" className="outline-none" />
                        <span className="">Lembrar-me</span>
                    </div>

                    <a className="outline-none text-red" href="/">
                        Esqueceu a senha?
                    </a>
                </div>
            </form>
        </div>
    );
};

export default FormLoginPageContainer;
