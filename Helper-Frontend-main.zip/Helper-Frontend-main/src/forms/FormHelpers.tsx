import RedButton from "../layout/RedButton";
import InputText from "../layout/InputText";
import Select from "../layout/Select";
import { useFormik } from "formik";
import * as yup from "yup";
import { latitude, longitude, ip } from "../validation/yup";
import { name, contract_id } from "../validation/yup";
import useFetchData from "../hooks/useFetchData";
import HelperServices from "../services/helper-services";
import AddCameras from "../components/AddCameras";

const initialState = {
    name: "",
    ip: "",
    latitude: "",
    longitude: "",
    contract_id: "",
};

const helperServices = new HelperServices("helpers");
const FormHelpers = () => {
    const { contratos } = useFetchData();

    const { handleChange, handleSubmit, values, errors, touched, handleBlur } =
        useFormik({
            initialValues: initialState,

            onSubmit: (values, { resetForm }) => {
                helperServices
                    .create({
                        name: values.name,
                        ip: values.ip,
                        latitude: values.latitude,
                        longitude: values.longitude,
                        contract_id: +values.contract_id,
                    })
                    .then((data) => resetForm());
            },

            validationSchema: yup.object({
                ip: ip,
                name: name,
                contract_id: contract_id,
                latitude: latitude,
                longitude: longitude,
            }),
        });

    return (
        <form
            onSubmit={handleSubmit}
            className="grid grid-cols-2 mt-10 gap-x-10 gap-y-5"
        >
            <InputText
                label="Nome do Helper"
                name="name"
                touched={touched.name}
                error={errors.name}
                handleBlur={handleBlur}
                handleChange={handleChange}
                value={values.name}
            />

            <div className="flex gap-2">
                <InputText
                    label="Latitude"
                    name="latitude"
                    touched={touched.latitude}
                    error={errors.latitude}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.latitude}
                />

                <InputText
                    label="Longitude"
                    name="longitude"
                    touched={touched.longitude}
                    error={errors.longitude}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.longitude}
                />
            </div>

            <div className="flex gap-2">
                <InputText
                    label="IP"
                    name="ip"
                    touched={touched.ip}
                    error={errors.ip}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.ip}
                />

                <Select
                    label="Contrato"
                    name="contract_id"
                    touched={touched.contract_id}
                    error={errors.contract_id}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.contract_id}
                    options={contratos}
                    question="Escolha seu contrato"
                />
            </div>

            <div></div>

            <hr className="my-4 border border-gray-300" />
            <hr className="my-4 border border-gray-300" />

            <AddCameras />

            <div></div>

            <div className="flex items-center justify-end gap-6">
                <a className="text-xs text-gray-800" href="/">
                    Cancelar
                </a>
                <RedButton>Salvar</RedButton>
            </div>
        </form>
    );
};

export default FormHelpers;
