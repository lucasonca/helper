export const styleCSS: React.CSSProperties = {
    fontWeight: "bold",
    backgroundColor: "black",
    color: "white",
};

export const styleCSS2: React.CSSProperties = { fontWeight: "bold" };

export const classes: string = "px-4 py-2.5 text-custom-black text-sm rounded";
