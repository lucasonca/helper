import { useState, useEffect } from "react";
import AppContext from "./AppContext";

const AppContextProvider = (props: any) => {
    const [currentUser, setCurrentUser] = useState(null);

    const [isIconHelperLogoOpen, setIsIconHelperLogoOpen] = useState(false);
    const [isIconOcorrenciasOpen, setIsIconOcorrenciasOpen] = useState(false);
    const [isIconControleHelperOpen, setIsIconControleHelperOpen] =
        useState(false);
    const [isIconGerenciadorAudioOpen, setIsIconGerenciadorAudioOpen] =
        useState(false);
    const [isIconNotificacoesOpen, setIsIconNotificacoesOpen] = useState(false);
    const [isIconConfiguracoesOpen, setIsIconConfiguracoesOpen] =
        useState(false);

    useEffect(() => {
        const loggedInUser = localStorage.getItem("user");

        if (loggedInUser) {
            const foundUser = JSON.parse(loggedInUser);

            setCurrentUser(foundUser); // turns a JSON string into a JS object
        }
    }, []);

    const iconsStates = {
        isIconHelperLogoOpen,
        setIsIconHelperLogoOpen,
        isIconOcorrenciasOpen,
        setIsIconOcorrenciasOpen,
        isIconControleHelperOpen,
        setIsIconControleHelperOpen,
        isIconGerenciadorAudioOpen,
        setIsIconGerenciadorAudioOpen,
        isIconNotificacoesOpen,
        setIsIconNotificacoesOpen,
        isIconConfiguracoesOpen,
        setIsIconConfiguracoesOpen,
    };

    const logoutHandler = () => {
        setCurrentUser(null);
        localStorage.removeItem("user");
    };

    const loginHandler = (data: any) => {
        setCurrentUser(data.user);
        localStorage.setItem("user", JSON.stringify(data.user)); // turns a JS object into a JSON string
    };

    const [isMessageVisible, setIsMessageVisible] = useState(false);

    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const openMenuSidebar = (): void => {
        setIsMenuOpen(true);
    };

    const closeMenuSidebar = (): void => {
        setIsMenuOpen(false);
    };

    const toggleMessagesContainer = (): void => {
        setIsMessageVisible((prev) => !prev);
    };

    const ctx: any = {
        isMenuOpen,
        openMenuSidebar,
        closeMenuSidebar,
        toggleMessagesContainer,
        isMessageVisible,
        loginHandler,
        logoutHandler,
        currentUser,
        iconsStates,
        setCurrentUser,
    };

    return (
        <AppContext.Provider value={ctx}>{props.children}</AppContext.Provider>
    );
};

export default AppContextProvider;
