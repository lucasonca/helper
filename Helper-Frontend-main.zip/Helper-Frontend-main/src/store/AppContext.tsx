import { createContext } from "react";

export interface IAppContext {
    isMenuOpen: boolean;
    openMenuSidebar: () => void;
    closeMenuSidebar: () => void;
    loginHandler: (data: any) => void;
    toggleMessagesContainer: () => void;
    isMessageVisible: boolean;
    isLoggedIn: boolean;
    logoutHandler: () => void;
    iconsStates: any;
}

const AppContext = createContext<IAppContext>({
    isMenuOpen: false,
    openMenuSidebar: () => {},
    closeMenuSidebar: () => {},
    loginHandler: () => {},
    toggleMessagesContainer: () => {},
    isMessageVisible: false,
    isLoggedIn: false,
    logoutHandler: () => {},
    iconsStates: {},
});

export default AppContext;
