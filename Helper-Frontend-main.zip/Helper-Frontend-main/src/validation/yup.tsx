import * as yup from "yup";

export const latitude = yup
    .string()
    .matches(
        /^(\+|-)?((\d((\.)|\.\d{1,6})?)|(0*?[0-8]\d((\.)|\.\d{1,6})?)|(0*?90((\.)|\.0{1,6})?))$/,
        "Latitude inválida"
    )
    .min(3, "Mínimo 3 dígitos")
    .required("Digite a latitude");

export const contract_id = yup.string().required("Digite seu contrato");

export const phoneRegExp =
    /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

export const longitude = yup
    .string()
    .matches(
        /^(\+|-)?((\d((\.)|\.\d{1,6})?)|(0*?\d\d((\.)|\.\d{1,6})?)|(0*?1[0-7]\d((\.)|\.\d{1,6})?)|(0*?180((\.)|\.0{1,6})?))$/,
        "Longitude inválida"
    )
    .min(3, "Mínimo 3 dígitos")
    .required("Digite a longitude");

export const ip = yup
    .string()
    .matches(/(^(\d{1,3}\.){3}(\d{1,3})$)/, {
        message: "Endereço de IP inválido",
        excludeEmptyString: true,
    })
    .typeError("Digite um número de IP válido")
    .test(
        "ipAddress",
        "Valor do endereço de IP deve ser menor ou igual 255",
        (value: any) => {
            if (value === undefined || value.trim() === "") return true;
            return (
                value.split(".").find((i: any) => parseInt(i) > 255) ===
                undefined
            );
        }
    )
    .required("Digite o IP");

export const name = yup
    .string()
    .min(3, "Mínimo 3 dígitos")
    .required("Digite o nome");

export const password = yup
    .string()
    .min(6, "Mínimo 6 dígitos")
    .required("Digite sua senha");

export const helper_id = yup.string().required("Digite seu helper");

export const type_id = yup.string().required("Digite o tipo");

export const email = yup
    .string()
    .email("Digite um email válido")
    .min(8, "Mínimo 8 dígitos")
    .required("Digite seu email");

export const occurrences_validation = {
    description: yup.string().max(410, "Máximo 410 dígitos"),
    wounds_risk_death: yup.string(),
    local_author: yup.string(),
    armed_author: yup.string(),
    risk_tumult: yup.string(),
    requester_name: yup.string(),
    requester_telephone: yup
        .string()
        .matches(phoneRegExp, "Digite um número de telefone válido"),
    location: yup.string(),
    forward: yup.string(),
    blatant: yup.string(),
    occurrence_number: yup.string(),
    classification_id: yup.string().nullable(),
    // nature_id: yup.string().nullable(),

    // operator_id: yup.number().integer(),
    // employee_id: yup.number().integer(),
    // helper_id: yup.number().integer()

    // level: yup.string().required(),
    // type: yup.string().required(),
    // status: yup.number().required("Escolha o status"),
};

export const validationSchemaFormInstitutions = yup.object({
    name: name,
    contract_id: contract_id,
    helper_id: helper_id,
    type_id: type_id,
    street: yup
        .string()
        .min(8, "Mínimo 8 dígitos")
        .required("Digite seu endereço"),
    district: yup
        .string()
        .min(3, "Mínimo 3 dígitos")
        .required("Digite seu bairro"),
    number: yup
        .number()
        .integer()
        .typeError("Digite um número válido")
        .required("Digite o número"),
    responsible: yup
        .string()
        .min(3, "Mínimo 3 dígitos")
        .required("Digite o responsável"),
    zip_code: yup
        .number()
        .integer()
        .typeError("Digite um cep válido")
        .min(8, "Mínimo 8 dígitos")
        .required("Digite seu cep"),
    latitude: latitude,
    longitude: longitude,
    contato: yup
        .string()
        .min(8, "Mínimo 8 dígitos")
        .required("Digite o contato do responsavel"),
    phone: yup
        .string()
        .min(8, "Mínimo 8 dígitos")
        .required("Digite o telefone da instituição"),
});
