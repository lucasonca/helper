import { StrictMode } from "react";
import { render } from "react-dom";
import "./index.css";
import App from "./App";
import AppContextProvider from "./store/AppContextProvider";

const element = document.querySelector("#root");

render(
    <StrictMode>
        <AppContextProvider>
            <App />
        </AppContextProvider>
    </StrictMode>,
    element
);
