import ReactDOM from "react-dom";

import { NavLink } from "react-router-dom";

import AppContext, { IAppContext } from "../store/AppContext";

import NotificationWrapper from "../layout/NotificationWrapper";

import "../index.css";
import { IiconsStates } from "../ts/interfaces";
import {
    IconGerenciadorAudio,
    IconOcorrencias,
    IconControleHelper,
} from "../components/icons/Icons";
import { useContext } from "react";

interface IModalTotemProps {
    iconsStates: IiconsStates;
}

const ModalTotem = ({ iconsStates }: IModalTotemProps) => {
    console.log(iconsStates.isIconControleHelperOpen);
    const { openMenuSidebar }: IAppContext = useContext(AppContext);

    const styleCSS: React.CSSProperties = { backgroundColor: "gray" };

    return ReactDOM.createPortal(
        <div className="absolute z-10 p-3 space-y-5 bg-white rounded w-72 left-221px bottom-210px">
            <div className="flex items-start gap-2">
                <h1 className="text-2xl font-bold">TE1</h1>
                <h1 className="font-semibold text-1xl">
                    Totem Exemplo 1 Ipsumn is simply dummy text
                </h1>
            </div>
            <div className="flex justify-center gap-2">
                <NavLink
                    onClick={() => {
                        openMenuSidebar();
                        iconsStates.setIsIconControleHelperOpen.bind(
                            null,
                            true
                        );
                    }}
                    activeStyle={styleCSS}
                    className="grid w-10 h-10 p-2 bg-black rounded place-items-center"
                    to="/home/controle-helper"
                >
                    <IconControleHelper />
                </NavLink>

                <NavLink
                    onClick={() => {
                        openMenuSidebar();
                        iconsStates.setIsIconOcorrenciasOpen.bind(null, true);
                    }}
                    activeStyle={styleCSS}
                    className="grid w-10 h-10 p-2 bg-black rounded place-items-center"
                    to="/home/ocorrencias/pendentes"
                >
                    <NotificationWrapper number={3}>
                        <IconOcorrencias />
                    </NotificationWrapper>
                </NavLink>

                <NavLink
                    onClick={() => {
                        openMenuSidebar();
                        iconsStates.setIsIconGerenciadorAudioOpen.bind(
                            null,
                            true
                        );
                    }}
                    activeStyle={styleCSS}
                    className="grid w-10 h-10 p-2 bg-black rounded place-items-center"
                    to="/home/gerenciador-audios/agenda"
                >
                    <IconGerenciadorAudio />
                </NavLink>
            </div>
            <div className="absolute transform -translate-x-1/2 -bottom-3 left-1/2 arrow-down"></div>
        </div>,
        document.querySelector("#overlays") as HTMLElement
    );
};

export default ModalTotem;
