import { useContext } from "react";
import ReactDOM from "react-dom";
import { HiOutlineX } from "react-icons/hi";
import AppContext, { IAppContext } from "../store/AppContext";

const ModalMessages = () => {
    const { toggleMessagesContainer }: IAppContext = useContext(AppContext);

    return ReactDOM.createPortal(
        <div className="absolute flex flex-col justify-between h-64 p-6 bg-white p bottom-10 right-10 rounded-xl w-96">
            <div className="flex justify-between">
                <h1 className="font-bold">Mensagens</h1>
                <HiOutlineX
                    onClick={toggleMessagesContainer}
                    className="w-8 h-8 text-gray-500 cursor-pointer"
                />
            </div>
            <div className="flex flex-col gap-2">
                <div className="self-end w-3/4 h-10 bg-gray-500 rounded-md"></div>
                <div className="w-3/4 h-10 bg-gray-500 rounded-md"></div>
            </div>
            <input
                type="text"
                className="w-full px-3 py-1 bg-gray-300 outline-none rounded-3xl"
                name=""
                id=""
            />
        </div>,
        document.querySelector("#messages-container") as HTMLElement
    );
};

export default ModalMessages;
