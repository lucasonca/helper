// import NotificationWrapper from "../layout/NotificationWrapper"
import { Link } from "react-router-dom";
import {
    IconGerenciadorAudio,
    IconOcorrencias,
    IconControleHelper,
    IconNotificacoes,
    IconConfiguracoes,
    IconHelperLogo,
} from "../components/icons/Icons";
import WeirdShapeIcons from "../layout/WeirdShapeIcons";
import { IiconsStates } from "../ts/interfaces";

interface ISidebarHomePageProps {
    iconsStates: IiconsStates;
}

const SidebarHomePage = ({ iconsStates }: ISidebarHomePageProps) => {
    return (
        <div className="fixed z-20 flex flex-col items-center justify-between w-16 h-screen py-6 bg-custom-black">
            <Link
                className={`w-10/12 self-end relative block`}
                to={`/home/perfil-container`}
                onClick={() => {
                    iconsStates.setIsIconControleHelperOpen(false);
                    iconsStates.setIsIconOcorrenciasOpen(false);
                    iconsStates.setIsIconGerenciadorAudioOpen(false);
                    iconsStates.setIsIconNotificacoesOpen(false);
                    iconsStates.setIsIconConfiguracoesOpen(false);
                    iconsStates.setIsIconHelperLogoOpen(true);
                }}
            >
                <WeirdShapeIcons isIconOpen={iconsStates.isIconHelperLogoOpen}>
                    <IconHelperLogo
                        isMenuOpen={iconsStates.isIconHelperLogoOpen}
                    />
                </WeirdShapeIcons>
            </Link>

            <div className="flex flex-col justify-center flex-grow w-full gap-16 my-16 2xl:gap-20">
                {/* <NotificationWrapper number={2} >
                    
                </NotificationWrapper> */}
                <Link
                    className={`w-10/12 self-end relative block`}
                    to={`/home/ocorrencias/pendentes`}
                    onClick={() => {
                        iconsStates.setIsIconControleHelperOpen(false);
                        iconsStates.setIsIconOcorrenciasOpen(true);
                        iconsStates.setIsIconGerenciadorAudioOpen(false);
                        iconsStates.setIsIconNotificacoesOpen(false);
                        iconsStates.setIsIconConfiguracoesOpen(false);
                        iconsStates.setIsIconHelperLogoOpen(false);
                    }}
                >
                    <WeirdShapeIcons
                        isIconOpen={iconsStates.isIconOcorrenciasOpen}
                    >
                        <IconOcorrencias
                            isMenuOpen={iconsStates.isIconOcorrenciasOpen}
                        />
                    </WeirdShapeIcons>
                </Link>

                <Link
                    className={`w-10/12 self-end relative block`}
                    to={`/home/controle-helper`}
                    onClick={() => {
                        iconsStates.setIsIconControleHelperOpen(true);
                        iconsStates.setIsIconOcorrenciasOpen(false);
                        iconsStates.setIsIconGerenciadorAudioOpen(false);
                        iconsStates.setIsIconNotificacoesOpen(false);
                        iconsStates.setIsIconConfiguracoesOpen(false);
                        iconsStates.setIsIconHelperLogoOpen(false);
                    }}
                >
                    <WeirdShapeIcons
                        isIconOpen={iconsStates.isIconControleHelperOpen}
                    >
                        <IconControleHelper
                            isMenuOpen={iconsStates.isIconControleHelperOpen}
                        />
                    </WeirdShapeIcons>
                </Link>

                <Link
                    className={`w-10/12 self-end relative block`}
                    to={`/home/gerenciador-audios/agenda`}
                    onClick={() => {
                        iconsStates.setIsIconControleHelperOpen(false);
                        iconsStates.setIsIconOcorrenciasOpen(false);
                        iconsStates.setIsIconGerenciadorAudioOpen(true);
                        iconsStates.setIsIconNotificacoesOpen(false);
                        iconsStates.setIsIconConfiguracoesOpen(false);
                        iconsStates.setIsIconHelperLogoOpen(false);
                    }}
                >
                    <WeirdShapeIcons
                        isIconOpen={iconsStates.isIconGerenciadorAudioOpen}
                    >
                        <IconGerenciadorAudio
                            isMenuOpen={iconsStates.isIconGerenciadorAudioOpen}
                        />
                    </WeirdShapeIcons>
                </Link>

                {/* <NotificationWrapper number={3} >
                    
                </NotificationWrapper> */}
                <Link
                    className={`w-10/12 self-end relative block`}
                    to={`/home/notificacoes`}
                    onClick={() => {
                        iconsStates.setIsIconControleHelperOpen(false);
                        iconsStates.setIsIconOcorrenciasOpen(false);
                        iconsStates.setIsIconGerenciadorAudioOpen(false);
                        iconsStates.setIsIconNotificacoesOpen(true);
                        iconsStates.setIsIconConfiguracoesOpen(false);
                        iconsStates.setIsIconHelperLogoOpen(false);
                    }}
                >
                    <WeirdShapeIcons
                        isIconOpen={iconsStates.isIconNotificacoesOpen}
                    >
                        <IconNotificacoes
                            isMenuOpen={iconsStates.isIconNotificacoesOpen}
                        />
                    </WeirdShapeIcons>
                </Link>
            </div>

            <Link
                className={`w-10/12 self-end relative block`}
                to={`/home/configuracoes/usuarios/cadastrar`}
                onClick={() => {
                    iconsStates.setIsIconControleHelperOpen(false);
                    iconsStates.setIsIconOcorrenciasOpen(false);
                    iconsStates.setIsIconGerenciadorAudioOpen(false);
                    iconsStates.setIsIconNotificacoesOpen(false);
                    iconsStates.setIsIconConfiguracoesOpen(true);
                    iconsStates.setIsIconHelperLogoOpen(false);
                }}
            >
                <WeirdShapeIcons
                    isIconOpen={iconsStates.isIconConfiguracoesOpen}
                >
                    <IconConfiguracoes
                        isMenuOpen={iconsStates.isIconConfiguracoesOpen}
                    />
                </WeirdShapeIcons>
            </Link>
        </div>
    );
};

export default SidebarHomePage;
