import { IInputFromUser } from "../hooks/useForm";

import { VscClose } from "react-icons/vsc";

interface IShowInputsProps {
    delete: (id: string) => void;
    array: Array<IInputFromUser>;
}

const ShowInputs = (props: IShowInputsProps) => {
    return (
        <>
            {props.array.length !== 0 && (
                <div className="flex flex-wrap gap-1 text-sm">
                    {props.array.map((input) => (
                        <div
                            key={input.id}
                            className="flex items-center gap-2 p-2 text-gray-500 rounded bg-greyish"
                        >
                            <span>{input.text}</span>
                            <VscClose
                                onClick={props.delete.bind(null, input.id)}
                                className="cursor-pointer"
                            />
                        </div>
                    ))}
                </div>
            )}
        </>
    );
};

export default ShowInputs;
