import { FiCamera } from "react-icons/fi";
import OccurrenceServices from "../../services/occurrence-services";
import ShowInputs from "../ShowInputs";
import NenhumHelperSelecionado from "../../layout/NenhumHelperSelecionado";
import FormSearchbar from "../../forms/FormSearchbar";
import { useForm } from "../../hooks/useForm";
import FormEditarUmaOcorrencia from "../../forms/FormEditarUmaOcorrencia";
import {
    ExpandIcon,
    Giroflex,
    AudiosAgendados,
    AutoFalante,
    Intercomunicador,
} from "../icons/Icons";
import { useContext, useEffect, useState } from "react";
import AppContext from "../../store/AppContext";
import { useHistory } from "react-router-dom";

const amountOfCameras = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

const occurrenceServices = new OccurrenceServices("occurrences");
const ControleHelperContainer = () => {
    const [occurrenceToBeEdited, setOccurrenceToBeEdited]: any[] = useState({});
    const [isLoading, setIsLoading] = useState(false);

    const history: any = useHistory();

    const [isFull, setIsFull] = useState(false);
    const [isGiroflexActive, setIsGiroflexActive] = useState(false);
    const [isIntercomunicadorActive, setIsIntercomunicadorActive] =
        useState(false);
    const [isAutoFalanteActive, setIsAutoFalanteActive] = useState(false);
    const [areAudiosAgendadosActive, setAreAudiosAgendadosActive] =
        useState(false);

    const [cameras, setCameras] = useState(amountOfCameras);
    const [isAnyCameraExpanded, setIsAnyCameraExpanded] = useState(false);

    const {
        arraySearchField,
        inputChangeHandler,
        inputUser,
        submitInputFieldHandler,
        deleteInputSearch,
    } = useForm();

    const { openMenuSidebar } = useContext(AppContext);

    useEffect(() => {
        if (history.location.state) {
            setIsLoading(true);
            occurrenceServices.readAll().then((occurrences) => {
                const occurrence = occurrences.find(
                    (occurrence: any) =>
                        occurrence.id === history.location.state.id
                );

                setOccurrenceToBeEdited(occurrence);
                setIsLoading(false);
            });
        }

        openMenuSidebar();
        return () => {};
    }, [openMenuSidebar]);

    const expand = (id: number) => {
        setCameras([id]);
        setIsAnyCameraExpanded(true);
    };

    const collapse = () => {
        setCameras(amountOfCameras);
        setIsAnyCameraExpanded(false);
    };

    const toggleGiroflex = () => {
        if (
            !isIntercomunicadorActive &&
            !isAutoFalanteActive &&
            !areAudiosAgendadosActive
        ) {
            setIsGiroflexActive((prev) => !prev);
        }
    };

    const toggleIntercomunicador = () => {
        if (
            !isGiroflexActive &&
            !isAutoFalanteActive &&
            !areAudiosAgendadosActive
        ) {
            setIsIntercomunicadorActive((prev) => !prev);
        }
    };

    const toggleAutoFalante = () => {
        if (
            !isGiroflexActive &&
            !isIntercomunicadorActive &&
            !areAudiosAgendadosActive
        ) {
            setIsAutoFalanteActive((prev) => !prev);
        }
    };

    const toggleAudiosAgendados = () => {
        if (
            !isGiroflexActive &&
            !isIntercomunicadorActive &&
            !isAutoFalanteActive
        ) {
            setAreAudiosAgendadosActive((prev) => !prev);
        }
    };

    const toggleFullScreen = () => {
        console.log("Was clicked");
        setIsFull((prev) => !prev);
    };

    const jsx = (
        <div className="h-full ml-16 overflow-y-scroll custom-scroll">
            {!history.location.state && (
                <div className="flex flex-col w-3/4 h-screen pt-8 mx-auto gap-7">
                    <h1 className="text-2xl font-semibold text-center">
                        Controle Helper
                    </h1>

                    <FormSearchbar
                        placeholder="Selecione um helper"
                        w="w-full"
                        className="relative inline-block"
                        bg="bg-greyish"
                        onSubmit={submitInputFieldHandler}
                        value={inputUser}
                        onChange={(event: any) => inputChangeHandler(event)}
                    />

                    <ShowInputs
                        delete={deleteInputSearch}
                        array={arraySearchField}
                    />

                    <NenhumHelperSelecionado />
                </div>
            )}

            {history.location.state && (
                // <></>
                <div className="mx-8">
                    <h1 className="my-8 text-2xl font-semibold text-center">
                        Controle Helper
                    </h1>

                    <div className="relative py-3 bg-greyish">
                        <p className="text-sm">
                            Exemplo 1 Ipsumm is simply dummy text
                        </p>
                        {/* <h1 className="mb-5 text-xl text-red">
                            <span className="font-semibold">Tipo - </span>Botão
                            de usuário{" "}
                            <span className="text-gray-500">02/08/2021</span>
                        </h1>
                        <h1 className="mb-5 text-xl text-red">
                            <span className="font-semibold">Tipo - </span>
                            Emergência Escolar{" "}
                            <span className="text-gray-500">02/08/2021</span>
                        </h1> */}
                        <h1 className="mb-5 text-xl text-red">
                            <span className="font-semibold">Tipo - </span>
                            Emergência Professor{" "}
                            <span className="text-gray-500">02/08/2021</span>
                        </h1>{" "}
                        <ExpandIcon />
                        <div
                            className={`grid grid-cols-4 gap-2 min-h-256px relative`}
                        >
                            {cameras.map((c) => (
                                <div
                                    key={c}
                                    className={`text-4xl text-white font-semibold grid place-items-center ${
                                        isAnyCameraExpanded
                                            ? "absolute inset-0 "
                                            : "cursor-pointer "
                                    }bg-custom-black`}
                                    onClick={expand.bind(null, c)}
                                >
                                    <FiCamera className="w-6" />
                                </div>
                            ))}
                            {isAnyCameraExpanded && (
                                <button
                                    className="absolute grid grid-cols-2 bottom-2 right-2 z-19"
                                    onClick={collapse}
                                >
                                    {[0, 1, 2, 3].map((i) => (
                                        <span
                                            key={i}
                                            className="w-5 h-3 bg-white border border-custom-black"
                                        ></span>
                                    ))}
                                </button>
                            )}
                        </div>
                        <div className="flex items-center justify-center gap-2 py-3">
                            <Giroflex
                                toggleGiroflex={toggleGiroflex}
                                isGiroflexActive={isGiroflexActive}
                            />
                            <Intercomunicador
                                toggleIntercomunicador={toggleIntercomunicador}
                                isIntercomunicadorActive={
                                    isIntercomunicadorActive
                                }
                            />
                            <AutoFalante
                                toggleAutoFalante={toggleAutoFalante}
                                isAutoFalanteActive={isAutoFalanteActive}
                            />
                            <AudiosAgendados
                                toggleAudiosAgendados={toggleAudiosAgendados}
                                areAudiosAgendadosActive={
                                    areAudiosAgendadosActive
                                }
                            />
                        </div>
                    </div>

                    <FormEditarUmaOcorrencia
                        setOccurrenceToBeEdited={setOccurrenceToBeEdited}
                        occurrenceToBeEdited={occurrenceToBeEdited}
                    />
                </div>
            )}
        </div>
    );

    return !isLoading ? (
        jsx
    ) : (
        <div className="grid h-screen place-items-center">
            <p>Carregando...</p>
        </div>
    );
};

export default ControleHelperContainer;
