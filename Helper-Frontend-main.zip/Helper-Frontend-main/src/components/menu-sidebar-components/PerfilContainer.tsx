import { useContext, useEffect } from "react";
import AppContext from "../../store/AppContext";
import BlackButton from "../../layout/BlackButton";
import FormPerfilContainer from "../../forms/FormPerfilContainer";
import { useHistory } from "react-router-dom";

const PerfilContainer = () => {
    const {
        openMenuSidebar,
        logoutHandler,
        closeMenuSidebar,
        iconsStates,
    }: any = useContext(AppContext);
    const history = useHistory();

    useEffect(() => {
        openMenuSidebar();
    }, [openMenuSidebar]);

    return (
        <div className="h-screen ml-16 overflow-y-scroll custom-scroll">
            <div className="flex flex-col gap-5 m-8">
                <h1 className="text-2xl font-semibold text-center">Perfil</h1>

                <FormPerfilContainer />

                <BlackButton
                    onClick={() => {
                        logoutHandler();

                        history.push("/login");

                        iconsStates.setIsIconHelperLogoOpen(false);

                        closeMenuSidebar();
                    }}
                    style="mr-3 mx-auto mt-44"
                >
                    Sair
                </BlackButton>
            </div>
        </div>
    );
};

export default PerfilContainer;
