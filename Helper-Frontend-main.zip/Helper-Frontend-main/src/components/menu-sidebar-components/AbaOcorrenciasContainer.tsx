import { useContext, useEffect } from "react";
import AppContext from "../../store/AppContext";
import {
    Switch,
    Route,
    RouteComponentProps,
    useRouteMatch,
} from "react-router-dom";
import ShowInputs from "../ShowInputs";
import FormSearchbar from "../../forms/FormSearchbar";
import CardsOcorrenciasPendentes from "../cards/CardsOcorrenciasPendentes";
import CardsOcorrenciasAndamento from "../cards/CardsOcorrenciasAndamento";
import CardsOcorrenciasFinalizados from "../cards/CardsOcorrenciasFinalizados";
import { useForm } from "../../hooks/useForm";
import ButtonsSwitch, { Iurls } from "../../layout/ButtonsSwitch";
import OccurrenceServices from "../../services/occurrence-services";
import { useState } from "react";
import { LoadingSpinner } from "../LoadingSpinner";

export interface CardsAndamentoEFinalizadosType {
    id: number;
    title: string;
    classificacao: string;
    natureza: string;
    date: string;
}

// fake data
export const cardsFinalizados: CardsAndamentoEFinalizadosType[] = [
    {
        id: 1,
        title: "TE1 - Totem Exemplo 1 Ipsumm is simply dummy text",
        classificacao: "Classificação: Botão de usuário",
        natureza: "Apoio ambiental",
        date: "23/09/2021",
    },
    {
        id: 2,
        title: "TE1 - Totem Exemplo 2 Ipsumm is simply dummy text",
        classificacao: "Classificação: Botão de usuário",
        natureza: "Apoio ambiental",
        date: "23/09/2021",
    },
];

const urls: Array<Iurls> = [
    { text: "Pendentes", url: "/home/ocorrencias/pendentes", id: 1 },
    { text: "Em Andamento", url: "/home/ocorrencias/em-andamento", id: 2 },
    { text: "Finalizados", url: "/home/ocorrencias/finalizados", id: 3 },
];

const occurrenceServices = new OccurrenceServices("occurrences");
const AbaOcorrenciasContainer = () => {
    const [cardsPendentes, setCardsPendentes] = useState<any>([]); // hooks
    const [cardsAndamento, setCardsAndamento] = useState<any>([]); // hooks
    const [cardsFinalizados, setCardsFinalizados] = useState<any>([]); // hooks
    const [isLoading, setIsLoading] = useState(false);

    const match: RouteComponentProps["match"] = useRouteMatch();

    const {
        arraySearchField,
        inputUser,
        inputChangeHandler,
        deleteInputSearch,
        submitInputFieldHandler,
    } = useForm();

    const { openMenuSidebar } = useContext(AppContext);

    useEffect(() => {
        openMenuSidebar();

        setIsLoading(true);

        // for good performance you should use socket.io
        const timer = setInterval(() => {
            occurrenceServices.readAll().then((occurrences) => {
                const pendentes = occurrences.filter(
                    (occurrence: any) => occurrence.status === 0
                );
                setCardsPendentes(pendentes);

                const andamentos = occurrences.filter(
                    (occurrence: any) => occurrence.status === 1
                );
                setCardsAndamento(andamentos);

                const finalizados = occurrences.filter(
                    (occurrence: any) => occurrence.status === 2
                );
                setCardsFinalizados(finalizados);

                setIsLoading(false);
            });
        }, 1000);

        return () => clearInterval(timer);
    }, [openMenuSidebar, occurrenceServices.readAll]);

    return (
        <div className="h-full ml-16 overflow-y-scroll custom-scroll">
            <div className="flex flex-col h-screen">
                <div className="relative flex flex-col flex-grow-0 gap-6 m-8">
                    {/* title */}
                    <h1 className="text-2xl font-semibold text-center">
                        Ocorrências
                    </h1>

                    <ButtonsSwitch urls={urls} />

                    <FormSearchbar
                        onSubmit={submitInputFieldHandler}
                        placeholder="Buscar ex: Totem, Ocorrência, Data, Nome"
                        w="w-full"
                        className="relative inline-block"
                        bg="bg-greyish"
                        value={inputUser}
                        onChange={(event: any) => inputChangeHandler(event)}
                    />

                    <ShowInputs
                        array={arraySearchField}
                        delete={deleteInputSearch}
                    />

                    {!isLoading && match.url === "/home/ocorrencias/pendentes" && (
                        <p className="text-sm">
                            Pendentes:{" "}
                            <span className="text-red">
                                {cardsPendentes.length}
                            </span>
                        </p>
                    )}
                    {!isLoading &&
                        match.url === "/home/ocorrencias/em-andamento" && (
                            <p className="text-sm">
                                Em andamento:{" "}
                                <span className="text-red">
                                    {cardsAndamento.length}
                                </span>
                            </p>
                        )}
                    {!isLoading &&
                        match.url === "/home/ocorrencias/finalizados" && (
                            <p className="text-sm">
                                Finalizados:{" "}
                                <span className="text-red">
                                    {cardsFinalizados.length}
                                </span>
                            </p>
                        )}
                </div>

                <>
                    {isLoading ? (
                        <div className="absolute transform -translate-x-1/2 -translate-y-1/2 top-1/2 right-1/2">
                            <LoadingSpinner />
                        </div>
                    ) : (
                        <Switch>
                            <Route path={`/home/ocorrencias/pendentes`}>
                                <CardsOcorrenciasPendentes
                                    cardsPendentes={cardsPendentes}
                                />
                            </Route>
                            <Route path={`/home/ocorrencias/em-andamento`}>
                                <CardsOcorrenciasAndamento
                                    cardsAndamento={cardsAndamento}
                                />
                            </Route>
                            <Route path={`/home/ocorrencias/finalizados`}>
                                <CardsOcorrenciasFinalizados
                                    cardsFinalizados={cardsFinalizados}
                                />
                            </Route>
                        </Switch>
                    )}
                </>
            </div>
        </div>
    );
};

export default AbaOcorrenciasContainer;
