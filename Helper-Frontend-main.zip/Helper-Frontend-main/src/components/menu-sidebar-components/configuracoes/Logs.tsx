const listaDeUsuarios = [
    // fake data
    {
        id: 1,
        chave: "Lorem Ipsum is simply",
        descricao: "Lorem Ipsum is simply",
        dataRegistro: "00/00/0000 00:00:00",
        dados: "Lorem Ipsum is simply",
    },
    {
        id: 2,
        chave: "Lorem Ipsum is simply",
        descricao: "Lorem Ipsum is simply",
        dataRegistro: "00/00/0000 00:00:00",
        dados: "Lorem Ipsum is simply",
    },
    {
        id: 3,
        chave: "Lorem Ipsum is simply",
        descricao: "Lorem Ipsum is simply",
        dataRegistro: "00/00/0000 00:00:00",
        dados: "Lorem Ipsum is simply",
    },
    {
        id: 4,
        chave: "Lorem Ipsum is simply",
        descricao: "Lorem Ipsum is simply",
        dataRegistro: "00/00/0000 00:00:00",
        dados: "Lorem Ipsum is simply",
    },
    {
        id: 5,
        chave: "Lorem Ipsum is simply",
        descricao: "Lorem Ipsum is simply",
        dataRegistro: "00/00/0000 00:00:00",
        dados: "Lorem Ipsum is simply",
    },
    {
        id: 6,
        chave: "Lorem Ipsum is simply",
        descricao: "Lorem Ipsum is simply",
        dataRegistro: "00/00/0000 00:00:00",
        dados: "Lorem Ipsum is simply",
    },
];

const Logs = () => {
    return (
        <div className="pb-10 mx-20 mt-16">
            <table className="w-full">
                <thead>
                    <tr>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Chave
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Descrição
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Data de Registro
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Dados
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {listaDeUsuarios.map((item) => (
                        <tr key={item.id}>
                            <td className="text-left border border-solid border-greyish">
                                {item.chave}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.descricao}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.dataRegistro}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.dados}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Logs;
