import CadastrarHelpers from "./CadastrarHelpers";
import ListaHelpers from "./ListaHelpers";
import {
    Switch,
    Route,
    NavLink,
    RouteComponentProps,
    useHistory,
} from "react-router-dom";
import { styleCSS2 } from "../../../../constants/consts";
import { useEffect } from "react";

const Helpers = () => {
    const history: RouteComponentProps["history"] = useHistory();

    useEffect(() => {
        history.push("/home/configuracoes/helpers/cadastrar");
    }, [history]);

    return (
        <>
            <div className="flex gap-8 mx-20 mt-8 text-xl">
                <NavLink
                    activeStyle={styleCSS2}
                    to={{ pathname: `/home/configuracoes/helpers/cadastrar` }}
                    className=""
                >
                    Cadastrar
                </NavLink>
                <NavLink
                    activeStyle={styleCSS2}
                    to={`/home/configuracoes/helpers/lista`}
                    className=""
                >
                    Lista
                </NavLink>
            </div>
            <Switch>
                <Route exact path="/home/configuracoes/helpers/cadastrar">
                    <CadastrarHelpers />
                </Route>
                <Route exact path="/home/configuracoes/helpers/lista">
                    <ListaHelpers />
                </Route>
            </Switch>
        </>
    );
};

export default Helpers;
