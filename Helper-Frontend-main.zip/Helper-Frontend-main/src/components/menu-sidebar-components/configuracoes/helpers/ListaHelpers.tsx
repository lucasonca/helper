import useFetchData from "../../../../hooks/useFetchData";
import { LoadingSpinner } from "../../../LoadingSpinner";

const ListaHelpers = () => {
    const { helpers, isLoading } = useFetchData();

    return isLoading ? (
        <LoadingSpinner />
    ) : (
        <div className="pb-10 mx-20 mt-8">
            <table className="w-full">
                <thead>
                    <tr>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Nome do Helper
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            IP
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Latitude
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Longitude
                        </th>
                        <th className="text-left border border-solid bg-greyish border-greyish">
                            Contrato
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {helpers?.map((item) => (
                        <tr key={item.id}>
                            <td className="text-left border border-solid border-greyish">
                                {item.name}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.ip}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.latitude}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.longitude}
                            </td>
                            <td className="text-left border border-solid border-greyish">
                                {item.contract_id.name}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListaHelpers;
