import FormHelpers from "../../../../forms/FormHelpers";

const CadastrarHelpers = () => {
    return (
        <div className="pb-10 mx-20">
            <FormHelpers />
        </div>
    );
};

export default CadastrarHelpers;
