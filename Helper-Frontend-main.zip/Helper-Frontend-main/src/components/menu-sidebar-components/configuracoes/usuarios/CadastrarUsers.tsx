import FormUsers from "../../../../forms/FormUsers";

const CadastrarUsers = () => {
    return <FormUsers />;
};

export default CadastrarUsers;
