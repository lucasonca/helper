import { useEffect } from "react";
import {
    Switch,
    Route,
    NavLink,
    RouteComponentProps,
    useHistory,
} from "react-router-dom";
import { styleCSS2 } from "../../../../constants/consts";
import CadastrarUsers from "./CadastrarUsers";
import ListaUsers from "./ListaUsers";

const Usuarios = () => {
    const history: RouteComponentProps["history"] = useHistory();

    useEffect(() => {
        history.push("/home/configuracoes/usuarios/cadastrar");
    }, [history]);

    return (
        <>
            <div className="flex gap-8 mx-20 mt-8 text-xl">
                <NavLink
                    activeStyle={styleCSS2}
                    to={{ pathname: `/home/configuracoes/usuarios/cadastrar` }}
                    className=""
                >
                    Cadastrar
                </NavLink>
                <NavLink
                    activeStyle={styleCSS2}
                    to={`/home/configuracoes/usuarios/lista`}
                    className=""
                >
                    Lista
                </NavLink>
            </div>
            <Switch>
                <Route exact path="/home/configuracoes/usuarios/cadastrar">
                    <CadastrarUsers />
                </Route>
                <Route exact path="/home/configuracoes/usuarios/lista">
                    <ListaUsers />
                </Route>
            </Switch>
        </>
    );
};

export default Usuarios;
