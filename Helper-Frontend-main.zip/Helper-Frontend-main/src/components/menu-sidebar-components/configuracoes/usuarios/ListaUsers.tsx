import { useState, Fragment } from "react";
import ReadOnlyRow from "./ReadOnlyRow";
import EditableRowsModal from "./EditableRowsModal";
import UserServices from "../../../../services/user-services";
import ReactPaginate from "react-paginate";
import usePagination from "../../../../hooks/usePagination";
import useFetchData from "../../../../hooks/useFetchData";
import { LoadingSpinner } from "../../../LoadingSpinner";

const userServices = new UserServices("users");

const ListaUsers = () => {
    const { contratos, grupos, users, setUsers, isLoading } = useFetchData();

    const { pagesVisited, pageCount, usersPerPage, changePage } =
        usePagination(users);

    const [editFormData, setEditFormData] = useState<any>({
        status: "", //
        name: "",
        email: "",
        contact_number: "",
        contract_id: "", //
        group_id: "", //
        type_id: "", //
        password: "",
        confirm_password: "",
    });

    const [editUserId, setEditUserId] = useState(null);

    const handleEditFormChange = (
        event: React.FormEvent<HTMLFormElement> | any
    ) => {
        event.preventDefault();

        const fieldName = event.target.getAttribute("name");
        const fieldValue = event.target.value;

        const newFormData: any = { ...editFormData };
        newFormData[fieldName] = fieldValue;

        setEditFormData(newFormData);
    };

    const handleEditFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        const userToBeUpdated: any = users.find(
            (user: any) => user.id === editUserId
        );

        const contractID: any = contratos.find(
            (item: any) => item.name === editFormData.contract_id
        );
        const groupID: any = grupos.find(
            (item: any) => item.name === editFormData.group_id
        );

        const indexOfUserToBeUpdated = users.findIndex(
            (user: any) => user.id === editUserId
        );

        const newUsers: any = [...users];

        const editedUserForDB = {
            password: editFormData.password,
            status: editFormData.status === "ativo" ? true : false,
            confirm_password: editFormData.confirm_password,
            name: editFormData.name,
            email: editFormData.email,
            contact_number: editFormData.contact_number,
            contract_id: contratos[contractID.id - 1],
            group_id: grupos[groupID.id - 1],
            type_id: editFormData.type_id,
        };

        newUsers[indexOfUserToBeUpdated] = editedUserForDB;

        userServices
            .update(editedUserForDB, userToBeUpdated.id)
            .then((data) => {
                setUsers(newUsers);

                setEditUserId(null);
            });
    };

    const handleEditClick = (
        event: React.FormEvent<HTMLFormElement>,
        user: any
    ) => {
        event.preventDefault();
        setEditUserId(user.id);

        const formValues = {
            password: user.password,
            status: user.status,
            confirm_password: user.confirm_password,
            name: user.name,
            email: user.email,
            contact_number: user.contact_number,
            contract_id: user.contract_id,
            group_id: user.group_id,
            type_id: user.type_id,
        };

        setEditFormData(formValues);
    };

    const handleCancelClick = () => {
        setEditUserId(null);
    };

    const handleDeleteClick = (userId: string) => {
        const newUsers = [...users];

        const indexOfuserToBeDeleted = users.findIndex(
            (user: any) => user.id === userId
        );
        const userToBeDeleted: any = users.find(
            (user: any) => user.id === userId
        );

        newUsers.splice(indexOfuserToBeDeleted, 1);

        userToBeDeleted &&
            userServices
                .delete(userToBeDeleted.id)
                .then((data) => console.log(data));

        setUsers(newUsers);
    };

    const títulos = [
        "Status",
        "Nome",
        "Email",
        "Telefone",
        "Contrato",
        "Grupo",
        "Ações",
    ]; //, "Tipo"

    return isLoading ? (
        <LoadingSpinner />
    ) : (
        <div className="flex flex-col gap-2 pb-10 mx-20 mt-8">
            <form className="mb-10" onSubmit={handleEditFormSubmit}>
                {!isLoading && users.length === 0 && (
                    <p className="">Não há usuários</p>
                )}
                <table className="w-full border-collapse">
                    <thead>
                        <tr className="">
                            {títulos.map((titulo: any, id) => (
                                <th
                                    key={id}
                                    className="text-left border border-solid bg-greyish border-greyish"
                                >
                                    {titulo}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {!isLoading &&
                            users.length > 0 &&
                            users
                                .slice(
                                    pagesVisited,
                                    pagesVisited + usersPerPage
                                )
                                .map((user: any) => {
                                    return (
                                        <Fragment>
                                            {editUserId === user.id && (
                                                <EditableRowsModal
                                                    key={user.id}
                                                    editFormData={editFormData}
                                                    handleEditFormChange={
                                                        handleEditFormChange
                                                    }
                                                    handleCancelClick={
                                                        handleCancelClick
                                                    }
                                                />
                                            )}
                                            {editUserId !== user.id && (
                                                <ReadOnlyRow
                                                    key={user.id}
                                                    user={user}
                                                    handleEditClick={
                                                        handleEditClick
                                                    }
                                                    handleDeleteClick={
                                                        handleDeleteClick
                                                    }
                                                />
                                            )}
                                        </Fragment>
                                    );
                                })}
                    </tbody>
                </table>
            </form>
            <ReactPaginate
                marginPagesDisplayed={2}
                pageRangeDisplayed={2}
                previousLabel={"Anterior"}
                nextLabel={"Próxima"}
                pageCount={pageCount}
                onPageChange={changePage}
                containerClassName={"paginationBttns"}
                previousLinkClassName={"previousBttn"}
                nextLinkClassName={"nextBttn"}
                disabledClassName={"paginationDisabled"}
                activeClassName={"paginationActive"}
            />
        </div>
    );
};

export default ListaUsers;
