const InputEditableRows = ({ value, placeholder, onChange, name }: any) => {
    return (
        <input
            className="rounded outline-none"
            type="text"
            required
            placeholder={placeholder}
            name={name}
            value={value}
            onChange={onChange}
        />
    );
};

export default InputEditableRows;
