import { RiDeleteBin6Fill } from "react-icons/ri";
import { AiOutlineEdit } from "react-icons/ai";

interface IReadOnlyRowProps {
    user: any;
    handleEditClick: (
        e: React.ChangeEvent<EventTarget | any>,
        user: any
    ) => void;
    handleDeleteClick: (id: string) => void;
}

const ReadOnlyRow = ({
    user,
    handleEditClick,
    handleDeleteClick,
}: IReadOnlyRowProps) => {
    return (
        <tr>
            <td className="text-left border border-solid border-greyish">
                {+user.status === 1 ? (
                    <span className="block w-4 h-4 bg-green-500 rounded-full"></span>
                ) : (
                    <span className="block w-4 h-4 rounded-full bg-red"></span>
                )}
            </td>
            <td className="text-left border border-solid border-greyish">
                {user.name}
            </td>
            <td className="text-left border border-solid border-greyish">
                {user.email}
            </td>
            <td className="text-left border border-solid border-greyish">
                {user.contact_number}
            </td>
            <td className="text-left border border-solid border-greyish">
                {user.contract_id.name}
            </td>
            <td className="text-left border border-solid border-greyish">
                {user.group_id.name}
            </td>
            {/* <td className="text-left border border-solid border-greyish">
                {user.roles}
            </td> */}
            <td className="text-left border-b border-r border-solid border-greyish">
                <span className="flex gap-2">
                    <button
                        className="text-indigo-500 cursor-pointer"
                        type="button"
                        onClick={(event) => handleEditClick(event, user)}
                    >
                        <AiOutlineEdit />
                    </button>
                    <button
                        className="cursor-pointer text-red"
                        type="button"
                        onClick={() => handleDeleteClick(user.id)}
                    >
                        <RiDeleteBin6Fill />
                    </button>
                </span>
            </td>
        </tr>
    );
};

export default ReadOnlyRow;
