import { GiCancel } from "react-icons/gi";
import { GetUsers } from "../../../../ts/interfaces";
import { AiOutlineSave } from "react-icons/ai";
import useFetchData from "../../../../hooks/useFetchData";
import InputEditableRows from "./InputEditableRows";

interface IEditableRowsModalProps {
    handleEditFormChange: (e: React.ChangeEvent<any>) => void;
    editFormData: GetUsers;
    handleCancelClick: () => void;
}

const EditableRowsModal = ({
    editFormData,
    handleEditFormChange,
    handleCancelClick,
}: IEditableRowsModalProps) => {
    const { contratos, grupos } = useFetchData();

    return (
        <div className="absolute grid gap-2 p-10 transform -translate-x-1/2 border border-black rounded inset-y-24 left-1/2 bg-greyish">
            <select
                name="status"
                onChange={handleEditFormChange}
                className="rounded outline-none cursor-pointer"
            >
                <option defaultValue="status">Status</option>
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo</option>
            </select>

            <InputEditableRows
                placeholder="Nome"
                value={editFormData.name}
                name="name"
                onChange={handleEditFormChange}
            />

            <InputEditableRows
                placeholder="Email"
                value={editFormData.email}
                name="email"
                onChange={handleEditFormChange}
            />

            <InputEditableRows
                placeholder="Telefone"
                value={editFormData.contact_number}
                name="contact_number"
                onChange={handleEditFormChange}
            />

            <select
                name="contract_id"
                onChange={handleEditFormChange}
                className="rounded outline-none cursor-pointer"
            >
                <option defaultValue="contrato">Contrato</option>
                {contratos &&
                    contratos.length > 0 &&
                    contratos.map((contrato: any) => (
                        <option key={contrato.id}>{contrato.name}</option>
                    ))}
            </select>

            <select
                name="group_id"
                onChange={handleEditFormChange}
                className="rounded outline-none cursor-pointer"
            >
                <option defaultValue="grupo">Grupo</option>
                {grupos &&
                    grupos.length > 0 &&
                    grupos.map((group: any) => (
                        <option key={group.id}>{group.name}</option>
                    ))}
            </select>

            <select
                name="type_id"
                onChange={handleEditFormChange}
                className="rounded outline-none cursor-pointer"
            >
                <option defaultValue="funcao">Função</option>
                <option value="admin">Admin</option>
                <option value="operador">Operador</option>
            </select>

            <InputEditableRows
                placeholder="Senha"
                name="password"
                onChange={handleEditFormChange}
            />

            <InputEditableRows
                placeholder="Confirmar Senha"
                name="confirm_password"
                onChange={handleEditFormChange}
            />

            <div className="text-sm text-left border border-solid border-greyish">
                <span className="flex gap-2">
                    <button
                        className="grid text-indigo-500 place-items-center"
                        type="submit"
                    >
                        <AiOutlineSave />
                    </button>
                    <button
                        className="grid place-items-center text-red"
                        type="button"
                        onClick={handleCancelClick}
                    >
                        <GiCancel />
                    </button>
                </span>
            </div>
        </div>
    );
};

export default EditableRowsModal;
