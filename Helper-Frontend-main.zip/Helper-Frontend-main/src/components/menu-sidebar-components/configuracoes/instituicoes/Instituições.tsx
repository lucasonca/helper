import {
    Switch,
    Route,
    NavLink,
    RouteComponentProps,
    useHistory,
} from "react-router-dom";
import CadastrarInstituicoes from "./CadastrarInstituicoes";
import ListaInstituicoes from "./ListaInstituicoes";
import { styleCSS2 } from "../../../../constants/consts";
import { useEffect } from "react";

const Instituições = () => {
    const history: RouteComponentProps["history"] = useHistory();

    useEffect(() => {
        history.push("/home/configuracoes/instituicoes/cadastrar");
    }, [history]);

    return (
        <>
            <div className="flex gap-8 mx-20 mt-8 text-xl">
                <NavLink
                    activeStyle={styleCSS2}
                    to={{
                        pathname: `/home/configuracoes/instituicoes/cadastrar`,
                    }}
                    className=""
                >
                    Cadastrar
                </NavLink>
                <NavLink
                    activeStyle={styleCSS2}
                    to={`/home/configuracoes/instituicoes/lista`}
                    className=""
                >
                    Lista
                </NavLink>
            </div>
            <Switch>
                <Route exact path="/home/configuracoes/instituicoes/cadastrar">
                    <CadastrarInstituicoes />
                </Route>
                <Route exact path="/home/configuracoes/instituicoes/lista">
                    <ListaInstituicoes />
                </Route>
            </Switch>
        </>
    );
};

export default Instituições;
