import FormInstituicoes from "../../../../forms/FormInstituicoes";

const CadastrarInstituicoes = () => (
    <div className="pb-10 mx-20">
        <FormInstituicoes />
    </div>
);

export default CadastrarInstituicoes;
