import { useState, useEffect } from "react";
import InstituicaoServices from "../../../../services/instituicao-services";
import { LoadingSpinner } from "../../../LoadingSpinner";

const títulos = [
    "Nome da Instituição",
    "Responsável",
    "Localização",
    "Contrato",
];

const instituicaoServices = new InstituicaoServices("institutions");
const ListaInstituicoes = () => {
    const [instituicoes, setInstituicoes] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        setIsLoading(true);
        const timer = setTimeout(() => {
            instituicaoServices.readAll().then((data) => {
                setInstituicoes(data);
                setIsLoading(false);
            });
        }, 4000);

        return () => clearTimeout(timer);
    }, []);

    return isLoading ? (
        <LoadingSpinner />
    ) : (
        <div className="flex flex-col gap-2 pb-10 mx-20">
            <table className="w-full mt-8 border-collapse">
                <thead>
                    <tr className="">
                        {títulos.map((titulo: any, id) => (
                            <th
                                key={id}
                                className="text-left border border-solid bg-greyish border-greyish"
                            >
                                {titulo}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {instituicoes.map((inst) => (
                        <Instituicao instituicao={inst} />
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListaInstituicoes;

const Instituicao = ({ instituicao }: any) => {
    return (
        <tr>
            <td className="text-left border border-solid border-greyish">
                {instituicao.name}
            </td>
            <td className="text-left border border-solid border-greyish">
                {instituicao.responsible}
            </td>
            <td className="text-left border border-solid border-greyish">
                {instituicao.street}
            </td>
            <td className="text-left border border-solid border-greyish">
                {instituicao.contract_id.name}
            </td>
        </tr>
    );
};
