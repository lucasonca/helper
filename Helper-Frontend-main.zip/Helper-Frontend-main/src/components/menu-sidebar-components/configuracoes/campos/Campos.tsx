import {
    NavLink,
    Switch,
    Route,
    useHistory,
    RouteComponentProps,
} from "react-router-dom";
import Contratos from "./Contratos";
import Grupos from "./Grupos";
import Classificacao from "./Classificacao";
import { styleCSS2 } from "../../../../constants/consts";
import { useEffect } from "react";

const Campos = () => {
    const history: RouteComponentProps["history"] = useHistory();

    useEffect(() => {
        history.push("/home/configuracoes/campos/contratos");
    }, [history]);

    return (
        <>
            <div className="flex gap-8 mx-20 mt-8 text-xl">
                <NavLink
                    activeStyle={styleCSS2}
                    to="/home/configuracoes/campos/contratos"
                    className=""
                >
                    Contratos
                </NavLink>
                <NavLink
                    activeStyle={styleCSS2}
                    to="/home/configuracoes/campos/grupos"
                    className=""
                >
                    Grupos
                </NavLink>
                <NavLink
                    activeStyle={styleCSS2}
                    to="/home/configuracoes/campos/classificacao"
                    className=""
                >
                    Classificação
                </NavLink>
            </div>
            <Switch>
                <Route exact path="/home/configuracoes/campos/contratos">
                    <Contratos />
                </Route>
                <Route exact path="/home/configuracoes/campos/grupos">
                    <Grupos />
                </Route>
                <Route exact path="/home/configuracoes/campos/classificacao">
                    <Classificacao />
                </Route>
            </Switch>
        </>
    );
};

export default Campos;
