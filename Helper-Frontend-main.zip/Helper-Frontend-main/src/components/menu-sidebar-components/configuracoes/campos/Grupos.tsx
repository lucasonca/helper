import BlackButton from "../../../../layout/BlackButton";
import RedButton from "../../../../layout/RedButton";
import useHttp from "../../../../hooks/useHttp";
import InputText from "../../../../layout/InputText";
import { LoadingSpinner } from "../../../LoadingSpinner";

const Grupos = () => {
    const {
        handleSubmit,
        data: grupos,
        handleChange,
        handleBlur,
        values,
        errors,
        touched,
        isLoading,
    } = useHttp("groups");

    return (
        <div className="grid grid-cols-3 gap-10 pb-10 mx-20 mt-24">
            <form className="flex flex-col gap-y-2" onSubmit={handleSubmit}>
                <InputText
                    style={{ flex: 0 }}
                    label="Grupo"
                    name="name"
                    touched={touched.name}
                    error={errors.name}
                    handleBlur={handleBlur}
                    handleChange={handleChange}
                    value={values.name}
                />

                <BlackButton>Adicionar Grupos</BlackButton>
            </form>

            {isLoading ? (
                <LoadingSpinner />
            ) : (
                <form className="col-start-2 col-end-4">
                    <div className="flex flex-col gap-2">
                        <h1 className="px-6 text-sm font-semibold">Grupos</h1>

                        {!isLoading && grupos.length === 0 && (
                            <p className="px-6">Não há grupos</p>
                        )}
                        {!isLoading &&
                            grupos &&
                            grupos.map((contrato) => (
                                <div
                                    key={contrato.id}
                                    className={`${
                                        +contrato.id % 2 === 0
                                            ? "bg-gray-300"
                                            : "bg-greyish"
                                    } flex px-6`}
                                >
                                    <span
                                        key={contrato.id}
                                        className={`${
                                            +contrato.id % 2 === 0
                                                ? "bg-gray-300"
                                                : "bg-greyish"
                                        } flex-grow py-4 text-sm outline-none`}
                                    >
                                        {contrato.name}
                                    </span>
                                    {/* <button className="text-sm text-red">Editar</button> */}
                                </div>
                            ))}
                    </div>
                    <div className="flex items-center justify-end col-start-2 col-end-3 row-start-5 row-end-6 gap-6 mt-10">
                        <a className="text-xs text-gray-800" href="/">
                            Cancelar
                        </a>
                        <RedButton>Salvar</RedButton>
                    </div>
                </form>
            )}
        </div>
    );
};

export default Grupos;
