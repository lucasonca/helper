import { Switch, Route } from "react-router-dom";
import Permissoes from "./permissoes/Permissoes";
import Usuarios from "./usuarios/Usuarios";
import Instituições from "./instituicoes/Instituições";
import Helpers from "./helpers/Helpers";
import Campos from "./campos/Campos";
import Logs from "./Logs";
import NavbarConfig from "../../NavbarConfig";
import { useContext, useEffect } from "react";
import AppContext from "../../../store/AppContext";

const ConfiguracoesContainer = () => {
    const { openMenuSidebar } = useContext(AppContext);

    useEffect(() => {
        openMenuSidebar();
    }, [openMenuSidebar]);

    return (
        <div className="w-full pl-16">
            <NavbarConfig />

            <Switch>
                <Route exact path="/home/configuracoes/usuarios/:p3?">
                    <Usuarios />
                </Route>
                <Route exact path="/home/configuracoes/permissoes/:p3?">
                    <Permissoes />
                </Route>
                <Route exact path="/home/configuracoes/instituicoes/:p3?">
                    <Instituições />
                </Route>
                <Route exact path="/home/configuracoes/helpers/:p3?">
                    <Helpers />
                </Route>
                <Route exact path="/home/configuracoes/campos/:p3?">
                    <Campos />
                </Route>
                <Route exact path="/home/configuracoes/logs/:p3?">
                    <Logs />
                </Route>
            </Switch>
        </div>
    );
};

export default ConfiguracoesContainer;
