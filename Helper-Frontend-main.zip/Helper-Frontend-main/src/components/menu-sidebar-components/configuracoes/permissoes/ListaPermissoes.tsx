import React from "react";

const ListaPermissoes = () => {
    return <div className="mx-20">work in progress</div>;
};

export default ListaPermissoes;
