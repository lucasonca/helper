import {
    Switch,
    Route,
    NavLink,
    RouteComponentProps,
    useHistory,
} from "react-router-dom";
import CadastrarPermissoes from "./CadastrarPermissoes";
import ListaPermissoes from "./ListaPermissoes";
import { styleCSS2 } from "../../../../constants/consts";
import { useEffect } from "react";

const Permissoes = () => {
    const history: RouteComponentProps["history"] = useHistory();

    useEffect(() => {
        history.push("/home/configuracoes/permissoes/cadastrar");
    }, [history]);

    return (
        <>
            <div className="flex gap-8 mx-20 mt-8 text-xl">
                <NavLink
                    activeStyle={styleCSS2}
                    to={{
                        pathname: `/home/configuracoes/permissoes/cadastrar`,
                    }}
                    className=""
                >
                    Cadastrar
                </NavLink>
                <NavLink
                    activeStyle={styleCSS2}
                    to={`/home/configuracoes/permissoes/lista`}
                    className=""
                >
                    Lista
                </NavLink>
            </div>
            <Switch>
                <Route exact path="/home/configuracoes/permissoes/cadastrar">
                    <CadastrarPermissoes />
                </Route>
                <Route exact path="/home/configuracoes/permissoes/lista">
                    <ListaPermissoes />
                </Route>
            </Switch>
        </>
    );
};

export default Permissoes;
