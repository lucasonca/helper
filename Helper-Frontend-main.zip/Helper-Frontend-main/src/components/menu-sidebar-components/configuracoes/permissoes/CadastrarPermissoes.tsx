import React from "react";

const CadastrarPermissoes = () => {
    return <div className="mx-20">work in progress</div>;
    // return (
    //     <fieldset className="">
    //         <legend className="text-sm font-semibold">Permissão (Ocorrência)</legend>
    //         <div className="flex gap-4 px-2.5 py-2">
    //             <InputTypeCheckbox htmlFor="criar" placeholder="Criar" className="cursor-pointer" id="criar">Criar</InputTypeCheckbox>
    //             <InputTypeCheckbox htmlFor="editar" placeholder="Editar" className="cursor-pointer" id="editar">Editar</InputTypeCheckbox>
    //             <InputTypeCheckbox htmlFor="excluir" placeholder="Excluir" className="cursor-pointer" id="excluir">Excluir</InputTypeCheckbox>
    //         </div>
    //     </fieldset>
    // )
};

export default CadastrarPermissoes;
