import { useContext, useEffect } from "react";
import AppContext from "../../store/AppContext";
import { LoadingSpinner } from "../LoadingSpinner";

const NotificacoesContainer = ({ occurrences, isLoading }: any) => {
    const { openMenuSidebar } = useContext(AppContext);

    useEffect(() => {
        openMenuSidebar();
    }, [openMenuSidebar]);

    return (
        <div className="flex flex-col h-screen gap-10 pt-8 ml-16 overflow-y-scroll custom-scroll">
            <h1 className="mx-8 text-2xl font-semibold text-center">
                Notificações
            </h1>
            <div className="flex flex-col flex-grow gap-3 pb-10 mx-8">
                {isLoading ? (
                    <LoadingSpinner />
                ) : (
                    <>
                        {occurrences.map((card: any) => {
                            return (
                                <a href="/" className="block" key={card.id}>
                                    <div className="relative w-full px-4 py-5 space-y-2 text-xs rounded bg-greyish">
                                        <div className="flex flex-col justify-center gap-2">
                                            <p className="font-bold">
                                                Totem: {card.helper_id.id}
                                            </p>
                                            <p>
                                                Endereço: {card.helper_id.name}
                                            </p>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="block text-gray-500 right-4 bottom-2">
                                                {card.created_at}
                                            </span>
                                        </div>
                                    </div>
                                </a>
                            );
                        })}
                    </>
                )}
            </div>
        </div>
    );
};

export default NotificacoesContainer;
