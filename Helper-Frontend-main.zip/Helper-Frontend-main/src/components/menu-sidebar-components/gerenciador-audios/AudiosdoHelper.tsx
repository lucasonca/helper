import { BsCloudUpload } from "react-icons/bs";

import { v4 } from "uuid";

import RedButton from "../../../layout/RedButton";
import ItemAudio from "../../cards/ItemAudio";

const listaAudios = [
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
    "01_UTILIZE A FAIXA DE PEDESTRE",
];

const AudiosDoHelper = () => {
    return (
        <>
            <RedButton>
                {/* upload file */}
                <span className="flex items-center gap-2">
                    <BsCloudUpload />
                    <span>Upload de Arquivo</span>
                </span>
            </RedButton>
            <div className="py-5">
                <div className="flex items-center justify-between mb-5">
                    <p className="text-xs font-semibold">Lista de Áudios</p>
                    <p className="text-xs">Selecionar para ação rápida</p>
                </div>
                {listaAudios.map((audio) => (
                    <ItemAudio key={v4()} audio={audio} />
                ))}
            </div>
        </>
    );
};

export default AudiosDoHelper;
