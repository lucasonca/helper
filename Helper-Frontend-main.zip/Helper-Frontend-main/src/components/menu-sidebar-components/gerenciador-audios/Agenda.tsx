import { IInputFromUser } from "../../../hooks/useForm";
import NenhumHelperSelecionado from "../../../layout/NenhumHelperSelecionado";
import CardAudios from "../../cards/CardAudios";
import { IcardsAgenda } from "./GerenciadorAudios";
import RedButton from "../../../layout/RedButton";
import { useState } from "react";
import FormAgendarAudios from "../../../forms/form-agendar-audios/FormAgendarAudios";

export interface IAgendaProps {
    arraySearchField: IInputFromUser[];
    cards: Array<IcardsAgenda>;
}

const Agenda = ({ arraySearchField, cards }: IAgendaProps) => {
    const [isFormVisible, setIsFormVisible] = useState(false);

    const toggleFormAppearance = () => {
        setIsFormVisible((prev) => !prev);
    };

    return (
        <>
            <RedButton onClick={toggleFormAppearance}>
                {isFormVisible ? "Voltar a Agenda" : "Agendar Áudios"}
            </RedButton>

            {arraySearchField.length === 0 && !isFormVisible && (
                <NenhumHelperSelecionado />
            )}

            {isFormVisible && <FormAgendarAudios />}

            {arraySearchField.length !== 0 &&
                arraySearchField.length > 0 &&
                !isFormVisible && (
                    <div className="relative flex flex-col flex-grow w-full gap-3 pb-6">
                        {cards.map((card) => (
                            <CardAudios key={card.id} c={card} />
                        ))}
                    </div>
                )}
        </>
    );
};

export default Agenda;
