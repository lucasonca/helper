import { Switch, Route } from "react-router-dom";
import ButtonsSwitch from "../../../layout/ButtonsSwitch";
import ShowInputs from "../../ShowInputs";
import { useForm } from "../../../hooks/useForm";
import FormSearchbar from "../../../forms/FormSearchbar";
import Agenda from "./Agenda";
import AudiosDoHelper from "./AudiosdoHelper";
import { useContext, useEffect } from "react";
import AppContext from "../../../store/AppContext";

export interface IcardsAgenda {
    id: number;
    text: string;
    periodo: string;
    dias: string;
    intervalo: string;
    horario: string;
}

const cardsAgenda: Array<IcardsAgenda> = [
    // fake data
    {
        id: 1,
        text: " - ULTILIZE A FAIXA DE PEDESTRES.wav",
        periodo: "Diário",
        dias: "Todos os dias",
        intervalo: "60min",
        horario: "07h - 22h",
    },
    {
        id: 2,
        text: " - VIOLÊNCIA CONTRA A MULHER.wav",
        periodo: "Diário",
        dias: "Todos os dias",
        intervalo: "60min",
        horario: "07h - 22h",
    },
    {
        id: 5,
        text: " - ALERTA IMPORTANTE COVID 19.wav",
        periodo: "Diário",
        dias: "Todos os dias",
        intervalo: "60min",
        horario: "07h - 22h",
    },
];

const urls = [
    { id: 1, text: "Agenda", url: "/home/gerenciador-audios/agenda" },
    {
        id: 2,
        text: "Áudios do Helper",
        url: "/home/gerenciador-audios/audios-helper",
    },
];

const GerenciadorAudiosContainer = () => {
    const {
        arraySearchField,
        deleteInputSearch,
        inputChangeHandler,
        inputUser,
        submitInputFieldHandler,
    } = useForm();

    const { openMenuSidebar } = useContext(AppContext);

    useEffect(() => {
        openMenuSidebar();
    }, [openMenuSidebar]);

    return (
        <div className="ml-16 overflow-y-scroll custom-scroll">
            <div className="flex flex-col h-screen p-8 gap-7">
                <h1 className="text-2xl font-semibold text-center">
                    Gerenciador de Áudios
                </h1>

                <ButtonsSwitch urls={urls} />

                <FormSearchbar
                    placeholder="Selecione totens"
                    w="w-full"
                    className="relative"
                    bg="bg-greyish"
                    onSubmit={submitInputFieldHandler}
                    value={inputUser}
                    onChange={(event: any) => inputChangeHandler(event)}
                />

                <ShowInputs
                    delete={deleteInputSearch}
                    array={arraySearchField}
                />

                <Switch>
                    <Route exact path="/home/gerenciador-audios/agenda">
                        <Agenda
                            cards={cardsAgenda}
                            arraySearchField={arraySearchField}
                        />
                    </Route>
                    <Route exact path="/home/gerenciador-audios/audios-helper">
                        <AudiosDoHelper />
                    </Route>
                </Switch>
            </div>
        </div>
    );
};

export default GerenciadorAudiosContainer;
