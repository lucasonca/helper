export const openIconControleHelper = (iconsStates: any) => {
    iconsStates.setIsIconControleHelperOpen(true);
    iconsStates.setIsIconOcorrenciasOpen(false);
    iconsStates.setIsIconGerenciadorAudioOpen(false);
    iconsStates.setIsIconNotificacoesOpen(false);
    iconsStates.setIsIconConfiguracoesOpen(false);
    iconsStates.setIsIconHelperLogoOpen(false);
};
