import ButtonSwitch from "../layout/ButtonsSwitch";
import { Iurls } from "../layout/ButtonsSwitch";

const urls: Array<Iurls> = [
    { text: "Usuários", url: "/home/configuracoes/usuarios", id: 1 },
    { text: "Permissões", url: "/home/configuracoes/permissoes", id: 2 },
    { text: "Instituições", url: "/home/configuracoes/instituicoes", id: 3 },
    { text: "Helpers", url: "/home/configuracoes/helpers", id: 4 },
    { text: "Campos", url: "/home/configuracoes/campos", id: 5 },
    { text: "Logs", url: "/home/configuracoes/logs", id: 6 },
];

const NavbarConfig = () => {
    return (
        <div className="flex items-center justify-between mx-20 my-8">
            <h1 className="flex-grow-0 text-2xl font-semibold">
                Configurações
            </h1>

            <ButtonSwitch urls={urls} />
        </div>
    );
};

export default NavbarConfig;
