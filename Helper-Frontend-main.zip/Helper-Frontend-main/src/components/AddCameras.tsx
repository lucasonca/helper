import InputText from "../layout/InputText";
import { ip, helper_id } from "../validation/yup";
import * as yup from "yup";
import { useState } from "react";

const validationSchema = yup.object().shape({
    // ip: ip,
    // user: yup.string().required("Digite seu nome"),
    // password: yup.string().required("Digite sua senha"),

    // helper_id: helper_id,
    // institution_id: helper_id,
    id_cameras: yup.string(),
});

const initialState = {
    // ip: "",
    // user: "",
    // password: "",

    // helper_id: "",
    // institution_id: "",
    id_cameras: "",
};

const AddCameras = ({ setCamerasList }: any) => {
    const [camera, setCamera] = useState(initialState);

    const handleChange = (e: any) => {
        setCamera((previousState: any) => ({
            ...previousState,
            [e.target.name]: e.target.value,
        }));
    };

    const onClick = () => {
        validationSchema
            .validate(
                {
                    id_cameras: camera.id_cameras,
                    // ip: camera.ip,
                    // user: camera.user,
                    // password: camera.password,

                    // helper_id: "1",
                    // institution_id: "1",
                },
                { abortEarly: false }
            )
            .then((value) => {
                if (value) {
                    setCamerasList((prev: any) => [
                        ...prev,
                        {
                            id_cameras: camera.id_cameras,
                            // ip: camera.ip,
                            // user: camera.user,
                            // password: camera.password,

                            // helper_id: "1", no form helper
                            // institution_id: "1", no form instituição
                        },
                    ]);
                }
            })
            .catch((error) => {
                console.log(error.inner[0].message);
            });
    };

    return (
        <>
            <div className="flex flex-col gap-y-2">
                {/* <InputText
                    label="IP"
                    name="ip"
                    handleChange={handleChange}
                    value={camera.ip}
                />

                <InputText
                    label="Usuário"
                    name="user"
                    handleChange={handleChange}
                    value={camera.user}
                />

                <InputText
                    label="Senha"
                    name="password"
                    handleChange={handleChange}
                    value={camera.password}
                /> */}

                <InputText
                    label="ID Câmera"
                    name="id_cameras"
                    handleChange={handleChange}
                    value={camera.id_cameras}
                />

                <button
                    onClick={onClick}
                    type="button"
                    className={`self-end px-4 py-2 text-xs text-white rounded outline-none bg-custom-black`}
                >
                    Adicionar Câmera
                </button>
            </div>

            <div className="flex flex-col gap-2">
                <h1 className="px-6 text-sm font-semibold">Câmeras</h1>
                <div className="flex items-center px-6 bg-gray-300">
                    <div
                        onChange={() => {}}
                        className="flex-grow py-2 text-sm bg-gray-300 outline-none"
                    >
                        139.98.167.1
                    </div>
                    <p className="text-sm text-red">Editar</p>
                </div>
                <div className="flex items-center px-6 bg-gray-300">
                    <div
                        onChange={() => {}}
                        className="flex-grow py-2 text-sm bg-gray-300 outline-none"
                    >
                        139.98.167.1
                    </div>
                    <p className="text-sm text-red">Editar</p>
                </div>
            </div>
        </>
    );
};

export default AddCameras;
