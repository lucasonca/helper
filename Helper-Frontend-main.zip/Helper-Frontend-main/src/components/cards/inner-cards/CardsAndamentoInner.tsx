import RedButton from "../../../layout/RedButton";
import BlackButton from "../../../layout/BlackButton";
import { AiOutlineEye } from "react-icons/ai";
import { useHistory } from "react-router-dom";
import OccurrenceServices from "../../../services/occurrence-services";

const occurrenceServices = new OccurrenceServices("occurrences");
const CardsAndamentoInner = ({ color, card }: any) => {
    const history = useHistory();

    const handleClick = () => {
        occurrenceServices
            .update({ status: 2 }, card.id)
            .then((data) => history.push("/home/ocorrencias/finalizados"));
    };

    return (
        <>
            <div>
                <h1 className="font-semibold">Descrição</h1>
                <p className="my-3">{card.description}</p>
            </div>
            <div>
                <div className="flex items-center gap-2">
                    <h1 className="flex-shrink-0 font-semibold">
                        Nível de risco
                    </h1>
                    <span className={`h-0.5 w-5/6 ${color}`}></span>
                </div>
                <div className="mt-2 mb-4 mr-7">
                    <ul>
                        <li className="flex justify-between">
                            <span>
                                1 - Há pessoas feridas em risco de morte?
                            </span>
                            <span>
                                {card.wounds_risk_death === 0
                                    ? "Sim"
                                    : card.wounds_risk_death === 1
                                    ? "Não"
                                    : "Suspeita"}
                            </span>
                        </li>
                        <li className="flex justify-between">
                            <span>2 - Autor do fato está no local?</span>
                            <span>
                                {card.local_author === 0
                                    ? "Sim"
                                    : card.local_author === 1
                                    ? "Não"
                                    : "Suspeita"}
                            </span>
                        </li>
                        <li className="flex justify-between">
                            <span>3 - Autor do fato está armado?</span>
                            <span>
                                {card.armed_author === 0
                                    ? "Sim"
                                    : card.armed_author === 1
                                    ? "Não"
                                    : "Suspeita"}
                            </span>
                        </li>
                        <li className="flex justify-between">
                            <span>4 - Há risco de tumulto no local?</span>
                            <span>
                                {card.risk_tumult === 0
                                    ? "Sim"
                                    : card.risk_tumult === 1
                                    ? "Não"
                                    : "Suspeita"}
                            </span>
                        </li>
                    </ul>
                </div>
                <div className="flex justify-between mb-4">
                    <div>
                        <h1 className="font-semibold">Classificação</h1>
                        <span>{card.classification_id.name}</span>
                    </div>
                    <div>
                        <h1 className="font-semibold">Natureza</h1>
                        <span>Ainda não está funcionando</span>{" "}
                        {/* hard-coded */}
                    </div>
                </div>
                <div>
                    <h1 className="font-semibold">Localização</h1>
                    <span>{card.location}</span>
                </div>
                <div className="flex justify-between my-4">
                    <div>
                        <h1 className="font-semibold">Solicitante</h1>
                        <span>{card.requester_name}</span>
                    </div>
                    <div>
                        <h1 className="font-semibold">Telefone</h1>
                        <span>{card.requester_telephone}</span>
                    </div>
                </div>
                <div className="flex items-center justify-end w-full gap-3 my-4">
                    <AiOutlineEye className="w-6 h-6" />
                    <RedButton onClick={handleClick}>
                        Finalizar Ocorrência
                    </RedButton>
                    <BlackButton>Editar</BlackButton>
                </div>
            </div>
        </>
    );
};

export default CardsAndamentoInner;
