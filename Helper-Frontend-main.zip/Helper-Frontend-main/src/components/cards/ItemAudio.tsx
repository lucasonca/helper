import { RiDeleteBin6Line } from "react-icons/ri";

interface IItemAudio {
    audio: string;
}

const ItemAudio = ({ audio }: IItemAudio) => {
    return (
        <div className="flex items-center justify-between px-4 py-2 my-1 rounded-md bg-greyish">
            <span className="text-sm">{audio}</span>
            <div className="flex items-center gap-2">
                <RiDeleteBin6Line />
                <input type="checkbox" name="" id="" />
            </div>
        </div>
    );
};

export default ItemAudio;
