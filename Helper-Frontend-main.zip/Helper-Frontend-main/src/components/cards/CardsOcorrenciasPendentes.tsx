import { useHistory } from "react-router-dom";
import { useContext } from "react";
import RedButton from "../../layout/RedButton";
import AppContext from "../../store/AppContext";
import { openIconControleHelper } from "../icons/openIconControleHelper";

const CardsOcorrenciasPendentes = ({ cardsPendentes }: any) => {
    const history = useHistory();
    const ctx: any = useContext(AppContext);

    const onClick = (id: any) => {
        openIconControleHelper(ctx.iconsStates);

        history.push({ pathname: "/home/controle-helper", state: { id } });
    };

    return (
        <div className="relative flex flex-col flex-grow w-full gap-3 p-8 bg-greyish">
            {cardsPendentes.map((card: any) => {
                return (
                    <div
                        key={card.id}
                        className="relative flex flex-col px-6 py-3 text-xs bg-white rounded shadow-md gap-y-2"
                    >
                        <div className="space-y-2">
                            <div className="flex gap-2">
                                <strong>Totem: {card.helper_id.id} - </strong>
                                {card.helper_id.name}
                            </div>
                            <p>Tipo: {card.type || "Botão usuário"}</p>
                            <div className="flex items-center justify-between">
                                <span className="block text-gray-500 right-4 bottom-2">
                                    {card.created_at}
                                </span>
                                <RedButton
                                    onClick={onClick.bind(null, card.id)}
                                >
                                    Visualizar Controle
                                </RedButton>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default CardsOcorrenciasPendentes;
