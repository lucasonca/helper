import CardsFinalizadoInner from "./inner-cards/CardsFinalizadoInner";
import AccordionOcorrencias from "./Accordions/AccordionOcorrencias";

const CardsOcorrenciasFinalizados = ({ cardsFinalizados }: any) => {
    const color = "bg-yellow-200";

    return (
        <div className="relative flex flex-col flex-grow w-full gap-3 p-8 bg-greyish">
            {cardsFinalizados.map((c: any) => (
                <AccordionOcorrencias color={color} key={c.id} card={c}>
                    <div className="">
                        <CardsFinalizadoInner card={c} color={color} />
                    </div>
                </AccordionOcorrencias>
            ))}
        </div>
    );
};

export default CardsOcorrenciasFinalizados;
