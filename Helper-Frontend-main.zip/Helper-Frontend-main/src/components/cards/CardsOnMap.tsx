import { LoadingSpinner } from "../LoadingSpinner";
import { useEffect } from "react";

const CardsOnMap = ({ occurrences, isLoading }: any) => {
    return (
        <div className="absolute space-y-0.5 z-5 right-12 top-9 overflow-y-scroll custom-scroll max-h-194px overflow-x-hidden">
            {isLoading && (
                <div className="grid w-64 h-64 bg-transparent place-items-center">
                    <LoadingSpinner />
                </div>
            )}

            {occurrences.map((card: any) => {
                return (
                    <a href="/" className="block" key={card.id}>
                        <div className="relative w-full px-4 py-5 space-y-2 text-xs rounded bg-greyish">
                            <div className="flex flex-col justify-center gap-2">
                                <p className="font-bold">
                                    Totem: {card.helper_id.id}
                                </p>
                                <p className="">{card.helper_id.name}</p>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="block text-gray-500 right-4 bottom-2">
                                    {card.created_at}
                                </span>
                            </div>
                        </div>
                    </a>
                );
            })}
        </div>
    );
};

export default CardsOnMap;
