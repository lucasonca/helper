import { MdKeyboardArrowDown, MdKeyboardArrowUp } from "react-icons/md";

import { useAccordion } from "../../../hooks/useAccordion";

interface IAccordionProps {
    card: any;
    children: JSX.Element;
    color: string;
}

const AccordionOcorrencias = (props: IAccordionProps) => {
    const { active, contentRef, toggleActive } = useAccordion();

    return (
        <div
            key={props.card.id}
            className="relative px-6 py-3 text-xs bg-white rounded shadow-md"
        >
            <span
                className={`absolute inset-y-0 left-0 w-3 ${props.color} rounded-l`}
            ></span>
            <div className="space-y-2">
                {/* <p className="font-bold">{props.card.description}</p> */}
                {!active && (
                    <>
                        <div className="flex flex-col justify-center gap-2">
                            <p>
                                <strong>
                                    Totem: {props.card.helper_id.id} -{" "}
                                </strong>
                                {props.card.helper_id.name}
                            </p>
                            <p>
                                <strong>Classificação: </strong>
                                {props.card.classification_id.name}
                            </p>
                            <p>
                                <strong>Natureza: </strong>
                                {/* hard coded */}
                                "Ainda não está funcionando"
                            </p>
                            <p className="self-end">{props.card.created_at}</p>
                        </div>
                    </>
                )}

                <span className="block text-right text-gray-500 right-4 bottom-2">
                    {props.card.date}
                </span>
            </div>
            <MdKeyboardArrowDown
                onClick={toggleActive}
                className={`w-6 h-6 text-gray-500 cursor-pointer top-1 right-1 ${
                    active ? "hidden" : "absolute"
                }`}
            />
            <MdKeyboardArrowUp
                onClick={toggleActive}
                className={`w-6 h-6 text-gray-500 cursor-pointer top-1 right-1 ${
                    !active ? "hidden" : "absolute"
                }`}
            />
            <div ref={contentRef}>{props.children}</div>
        </div>
    );
};

export default AccordionOcorrencias;
