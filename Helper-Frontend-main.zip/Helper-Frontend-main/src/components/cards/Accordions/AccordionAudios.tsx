import { MdKeyboardArrowDown, MdKeyboardArrowUp } from "react-icons/md";

import { IcardsAgenda } from "../../menu-sidebar-components/gerenciador-audios/GerenciadorAudios";
import { useAccordion } from "../../../hooks/useAccordion";

interface IAccordionProps {
    children: JSX.Element;
    card: IcardsAgenda;
}

const AccordionAudios = (props: IAccordionProps) => {
    const { active, contentRef, toggleActive } = useAccordion();

    return (
        <div className="relative w-full p-2 rounded-md bg-greyish">
            <h1
                className={`w-5/6 py-0.5 px-1.5 text-sm text-white rounded ${
                    props.card.text ===
                        " - ULTILIZE A FAIXA DE PEDESTRES.wav" ||
                    props.card.text === " - ALERTA IMPORTANTE COVID 19.wav"
                        ? "bg-yellow-400"
                        : "bg-custom-blue"
                }`}
            >{`${props.card.id < 10 ? "0" : ""}${props.card.id}${
                props.card.text
            }`}</h1>
            <MdKeyboardArrowDown
                onClick={toggleActive}
                className={`w-6 h-6 text-gray-500 cursor-pointer top-2 right-1 ${
                    active ? "hidden" : "absolute"
                }`}
            />
            <MdKeyboardArrowUp
                onClick={toggleActive}
                className={`w-6 h-6 text-gray-500 cursor-pointer top-2 right-1 ${
                    !active ? "hidden" : "absolute"
                }`}
            />
            <div ref={contentRef}>{props.children}</div>
        </div>
    );
};

export default AccordionAudios;
