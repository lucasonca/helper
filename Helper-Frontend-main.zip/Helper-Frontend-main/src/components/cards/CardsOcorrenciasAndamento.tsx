import CardsAndamentoInner from "./inner-cards/CardsAndamentoInner";
import AccordionOcorrencias from "./Accordions/AccordionOcorrencias";

const CardsOcorrenciasAndamento = ({ cardsAndamento }: any) => {
    const color = "bg-yellow-400";

    return (
        <div className="relative flex flex-col flex-grow w-full gap-3 p-8 bg-greyish">
            {cardsAndamento.map((c: any) => (
                <AccordionOcorrencias color={color} key={c.id} card={c}>
                    <div className="">
                        <CardsAndamentoInner card={c} color={color} />
                    </div>
                </AccordionOcorrencias>
            ))}
        </div>
    );
};

export default CardsOcorrenciasAndamento;
