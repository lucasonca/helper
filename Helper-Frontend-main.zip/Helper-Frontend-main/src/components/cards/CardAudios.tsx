import { RiDeleteBin6Line } from "react-icons/ri";

import AccordionAudios from "../cards/Accordions/AccordionAudios";
import { IcardsAgenda } from "../menu-sidebar-components/gerenciador-audios/GerenciadorAudios";

interface ICardAudiosProps {
    c: IcardsAgenda;
}

const CardAudios = ({ c }: ICardAudiosProps) => {
    return (
        <AccordionAudios card={c}>
            <table className="flex flex-col gap-2 mt-2">
                <thead>
                    <tr className="flex justify-center w-full text-sm gap-7">
                        <th>Período</th>
                        <th>Dias</th>
                        <th>Intervalo</th>
                        <th>Horário</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <tr className="flex justify-center w-full text-xs gap-7">
                        <td>{c.periodo}</td>
                        <td>{c.dias}</td>
                        <td>{c.intervalo}</td>
                        <td>{c.horario}</td>
                        <td>
                            <RiDeleteBin6Line />
                        </td>
                    </tr>
                </tbody>
            </table>
        </AccordionAudios>
    );
};

export default CardAudios;
