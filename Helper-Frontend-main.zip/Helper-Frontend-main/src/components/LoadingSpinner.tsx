import "../index.css";

export const LoadingSpinner = () => <div className="block spinner"></div>;
