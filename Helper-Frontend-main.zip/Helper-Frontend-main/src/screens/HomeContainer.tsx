import { useState, useContext, useEffect } from "react";
import CardsOnMap from "../components/cards/CardsOnMap";
import MenuSidebarContainer from "../layout/MenuSidebarContainer";
import SidebarHomePage from "../components/SidebarHomePage";
import LogoHelper from "../components/LogoHelper";
import FormSearchbar from "../forms/FormSearchbar";
import {
    RoundedRedIcon,
    School,
    RoundedRedIconWithYellowBorder,
    RoundedRedIconWithFadingBorder,
    MainIcon,
} from "../components/icons/Icons";
import "../index.css";
import ModalTotem from "../modals/ModalTotem";
import ModalMessages from "../modals/ModalMessages";
import AppContext from "../store/AppContext";
import MapView from "../map/MapView";
import OccurrenceServices from "../services/occurrence-services";

const occurrenceServices = new OccurrenceServices("occurrences");

const HomeContainer = () => {
    const [isModalOpen, setIsModalOpen] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const [occurrences, setOccurrences]: any[] = useState([]);
    const { isMessageVisible, iconsStates }: any = useContext(AppContext);

    useEffect(() => {
        setIsLoading(true);

        const timer = setInterval(() => {
            occurrenceServices.readAll().then((occurrences) => {
                setOccurrences(occurrences);
                setIsLoading(false);
            });
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const toggleModalHandler = () => {
        setIsModalOpen((prev) => !prev);
    };

    return (
        <div className="relative w-full h-screen">
            <MapView />

            <SidebarHomePage iconsStates={iconsStates} />

            <FormSearchbar
                placeholder="Pesquisar"
                w="w-80"
                className="absolute inline-block z-5 left-32 top-8"
            />

            <CardsOnMap occurrences={occurrences} isLoading={isLoading} />

            <LogoHelper />

            <MenuSidebarContainer
                occurrences={occurrences}
                isLoading={isLoading}
                iconsStates={iconsStates}
            />

            {!isModalOpen && <ModalTotem iconsStates={iconsStates} />}
            {isMessageVisible && <ModalMessages />}
        </div>
    );
};

export default HomeContainer;
