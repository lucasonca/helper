module.exports = {
  // mode: 'jit',
  purge: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      maxWidth: {
        '1024px': '1024px',
      },
      screens: {
        '1024px': '1024px',
      },
      // gridTemplateColumns: {
      //  '25': 'repeat( auto-fit, minmax(10%, 25%) )',
      // },
      minHeight: {
        '256px': '256px',
      },
      borderWidth: {
        "9px": "9px"
      },
      colors: {
        'red': '#FF2F2F',
        "custom-blue": "#4886FF",
        "custom-black": "#1D1D1D",
        "greyish": "#F4F4F4",
      },
      inset: {
        '28px': "28px",
        "-28px": "-28px",
        "-8px": "-8px",
        "0.14rem": "0.14rem",
        "26px": "26px",
        "-22px": "-22px",
        "-23px": "-23px",
      },
      spacing: {
        '67px': "67px",
        '38px': "38px",
        "1px": "1px",
        '194px': "194px",
        '166px': "166px",
        '221px': "221px",
        '270px': "270px",
        '463px': "463px",
        '210px': "210px",
        '45%': "45%",
        '1024px': "1024px",
      },
      zIndex: {
        '-1': -1,
        "5": 5,
        "4": 4,
        "19": 19,
      },
      backgroundImage: {
        'helper-bg': "url('/src/assets/images/helper-bg.png')",
        'map-bg': "url('/src/assets/images/map-bg.png')",
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}

