// imports
import * as dotenv from "dotenv";
import * as http from "http";
import axios from "axios";
import app from "../src/app";
import { SimpleConsoleLogger } from "typeorm";

// vars
dotenv.config();
export const wsPort: string = process.env.WS_PORT;

// websocket server
const wsServer = http.createServer(app);
const io = require("socket.io")(wsServer);

// clients
app.use("/totem", (req: any, res: any) => res.render("totem.html"));
app.use("/application", (req: any, res: any) => res.render("application.html"));

const types = [
    { id: 0, action: "BTN_USER", msg: "Botão usuário" },
    { id: 1, action: "APP_FIREMAN", msg: "Bombeiro" },
    { id: 2, action: "APP_DOCTOR", msg: "Médico" },
    { id: 3, action: "APP_POLICE", msg: "Policial" },
];

// server-side
io.on("connection", (socket: any) => {
    console.log(`New client connected: ${socket.id}`);

    socket.on("message", (occurrence: any) => {
        axios
            .get(`http://localhost:3002/helpers/${occurrence.helper_id}`)
            .then((data: any) => {
                if (data.data) {
                    axios
                        .post("http://localhost:3002/occurrences", occurrence)
                        .then((data) => console.log(data))
                        .catch((e) => console.log(e));
                } else {
                    console.log("This Helper is not registered!");
                }
            })
            .catch((err) => console.log(err));
    });

    socket.on("MSG_HELPER", (occurrence: any) => {
        console.log(occurrence);
        socket.broadcast.emit("MSG_HELPER", occurrence);
    });

    socket.on("MSG_CCO", (occurrence: any) => {
        console.log(occurrence);
        socket.broadcast.emit("MSG_CCO", occurrence);
    });

    socket.on("EVENT", (occurrence: any) => {
        console.log(occurrence);
        socket.broadcast.emit("EVENT", occurrence);
    });

    socket.on("BTN_USER", (data: any) => {
        console.log(data);
        io.to(data.id).emit("BTN_USER", data);
    });
});

export default wsServer;
