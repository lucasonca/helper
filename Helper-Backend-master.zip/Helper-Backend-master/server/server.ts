// imports
import * as dotenv from "dotenv";

import app from "../src/app";
import createConnection from "../database/connect";
import wsServer, { wsPort } from "./ws";
import * as path from "path";
// vars
dotenv.config();
const httpPort: string = process.env.HTTP_PORT;

// * Connect database default
createConnection("default")
    .then((_) =>
        console.log(" ✔️ [database]: Default database connected successfully.")
    )
    .catch((database_connection_error) =>
        console.log(
            ` ⚠ [database]: Default database was not connected! Error: ${database_connection_error.message}`
        )
    );

// * Run server
app.listen(httpPort, () => {
    console.log(`🚀 [HTTP server]: Server is running at :${httpPort}.`);
});

// * Run websocket
wsServer.listen(wsPort, () => {
    console.log(`🚀 [Websocket server]: Server is running at :${wsPort}.`);
});
