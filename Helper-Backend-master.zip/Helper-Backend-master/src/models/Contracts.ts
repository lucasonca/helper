import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  ManyToOne,
} from "typeorm";
import Users from "./Users";
import Helpers from "./Helpers";
import Institutions from "./Institutions";

@Entity()
export default class Contracts {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar',{length:100, nullable: true, unique: true })
  name: string;

  @Column('varchar',{length:100})
  hostname: string

  @Column({ nullable: true })
  type: number

  @Column('varchar',{length:15, nullable: true, unique: true })
  ip: string;

  @Column('varchar',{length:100, nullable: true })
  user: string;

  @Column('varchar',{length:15, nullable: true })
  password: string;

  @OneToMany( () => Users, users => users.id, {
    onDelete:"CASCADE"
  })
  users: Users[];

  @OneToMany( () => Helpers, helpers => helpers.id, {
    onDelete:"CASCADE"
  })
  helpers: Helpers[];

  @OneToMany( () => Institutions, institutions => institutions.id, {
    onDelete:"CASCADE"
  })
  institutions: Institutions[];

  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}

