import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
  JoinTable,
  ManyToOne
} from "typeorm";
import Cameras from "./Cameras";
import Contracts from "./Contracts";
import Institutions from "./Institutions";
import Occurrences from "./Occurrences";

@Entity()
export default class Helpers {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({unique: true})
  token: string;

  @Column()
  name: string;

  @Column('varchar',{length:15, nullable: true})
  ip:string;

  @Column("decimal", { precision: 15, scale: 8 })
  latitude: number;
  
  @Column("decimal", { precision: 15, scale: 8 })
  longitude: number;

  @ManyToOne( () => Contracts, contracts => contracts.id, {
    onDelete:"CASCADE",
    eager: true
  })
  @JoinColumn({ name: "contract_id" })
  contract_id: Contracts;

  @OneToMany( () => Institutions, institutions => institutions.id )
  institutions: Institutions[];

  @OneToMany( () => Cameras, cameras => cameras.id )
  cameras: Cameras[];

  @OneToMany( () => Occurrences, occurrences => occurrences.id )
  occurrences: Occurrences[];

  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}
