import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    OneToOne,
    JoinColumn,
    ManyToOne,
} from "typeorm";
import Classifications from "./Classifications";
import Natures from "./Natures";

@Entity()
export default class ClassificationNature {
    @PrimaryGeneratedColumn()
    id: number;

    @ManyToOne(() => Natures, (Natures) => Natures.id, {
        onDelete: "CASCADE",
        eager: true,
    })
    @JoinColumn()
    nature_id: Natures;

    @OneToOne(() => Classifications, (Classifications) => Classifications.id, {
        onDelete: "CASCADE",
        eager: true,
    })
    @JoinColumn()
    classification_id: Classifications;

    @CreateDateColumn({
        type: "timestamp",
        default: () => "CURRENT_TIMESTAMP(6)",
    })
    created_at: Date;

    @UpdateDateColumn({
        type: "timestamp",
        default: () => "CURRENT_TIMESTAMP(6)",
        onUpdate: "CURRENT_TIMESTAMP(6)",
    })
    updated_at: Date;
}
