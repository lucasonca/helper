import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn
} from "typeorm";
import Helpers from "./Helpers";
import Institutions from "./Institutions";

@Entity()
export default class Cameras {
  @PrimaryGeneratedColumn()
  id: number;

 @Column()
 id_camera: string;

  @ManyToOne( () => Helpers, helpers => helpers.id, {eager: true} )
  @JoinColumn({ name: "helper_id" })
  helper_id: Helpers;

  @ManyToOne( () => Institutions, institutions => institutions.id, {eager: true} )
  @JoinColumn({ name: "institution_id" })
  institution_id: Institutions;

  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}
