import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  JoinColumn,
  ManyToOne
} from "typeorm";
import Cameras from "./Cameras";
import Contracts from "./Contracts";
import Helpers from "./Helpers";
import InstitutionType from "./InstitutionType";
import Occurrences from "./Occurrences";

@Entity()
export default class Institutions {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({nullable: true })
  name: string;

  @Column({nullable: true })
  street: string;

  @Column({nullable: true })
  district: string;

  @Column({nullable: true })
  contato: string;

  @Column({nullable: true })
  phone: string;

  @Column({nullable: true })
  number: string;

  @Column('varchar',{length:10, nullable: true })
  responsible: string;

  @Column('varchar',{length:15, nullable: true })
  zip_code: string;

  @Column("decimal", { precision: 15, scale: 8 })
  latitude: number;

  @Column("decimal", { precision: 15, scale: 8 })
  longitude: number;

  @ManyToOne(() => Contracts, contracts => contracts.id, {
    onDelete: "CASCADE",
    nullable: true,
    eager: true
  })
  @JoinColumn()
  contract_id: Contracts;

  @ManyToOne(()=>Helpers, helpers => helpers.id,{
    onDelete: "CASCADE",
    eager: true
  })
  @JoinColumn()
  helper_id: Helpers;

  @ManyToOne(()=>InstitutionType, institutiontype => institutiontype .id,{
    onDelete: "CASCADE",
    nullable: true,
    eager: true
  })
  @JoinColumn()
  type_id : InstitutionType ;

  @OneToMany(() => Cameras, cameras => cameras.id)
  cameras: Cameras[];

  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}
