import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    JoinColumn,
    ManyToOne,
    OneToMany,
  } from "typeorm";
import Institutions from "./Institutions";

    import Institution from "./Institutions";
  
  @Entity()
  export default class InstitutionType {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({nullable: true, unique: true })
    name: string;
  
    @OneToMany(() => Institutions, institutions => institutions.id,  {
      onDelete:"CASCADE"
    })
    institutions: Institutions[];
    
    @CreateDateColumn({
      type: "timestamp",
      default: () => "CURRENT_TIMESTAMP(6)",
    })
    created_at: Date;
  
    @UpdateDateColumn({
      type: "timestamp",
      default: () => "CURRENT_TIMESTAMP(6)",
      onUpdate: "CURRENT_TIMESTAMP(6)",
    })
    updated_at: Date;
  }
  