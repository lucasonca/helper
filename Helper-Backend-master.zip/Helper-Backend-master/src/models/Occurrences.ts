import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import Classifications from "./Classifications";
import Helpers from "./Helpers";
import Institutions from "./Institutions";
import Natures from "./Natures";
import Users from "./Users";

@Entity()
export default class Occurrences {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  description: string;

  @Column()
  level: string;

  @Column()
  type: string;

  @Column()
  wounds_risk_death: number; // number

  @Column()
  local_author: number;

  @Column()
  armed_author: number;

  @Column()
  risk_tumult: number;

  @Column()
  requester_name: string;

  @Column()
  requester_telephone: string;

  @Column()
  location: string;

  @Column()
  forward: boolean;

  @Column()
  blatant: boolean;

  @Column()
  status: number;

  @Column()
  occurrence_number: string;

  @ManyToOne( () => Helpers, helpers => helpers.id, {
    onDelete:"CASCADE",
    eager: true
  } )
  @JoinColumn({ name: "helper_id" })
  helper_id: Helpers;

  @ManyToOne(()=>Classifications, classifications => classifications.id, {
    onDelete:"CASCADE",
    eager: true
  })
  @JoinColumn({ name: "nature_id" })
  classification_id: Classifications;

  @ManyToOne( () => Users, users => users.id, {
    onDelete:"CASCADE", eager: true
  } )
  @JoinColumn({ name: "operator_id" })
  operator_id: Users;

  @ManyToOne( () => Users, users => users.id, {
    onDelete:"CASCADE", eager: true
  } )
  @JoinColumn({ name: "employee_id" })
  employee_id: Users;


  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}
