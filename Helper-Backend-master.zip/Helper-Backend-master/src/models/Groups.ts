import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
} from "typeorm";
import Users from "./Users";

@Entity()
export default class Groups {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("varchar", { length: 100, nullable: true, unique: true })
    name: string;

    @OneToMany(() => Users, (users) => users.id, {
        onDelete: "CASCADE",
    })
    users: Users[];

    @CreateDateColumn({
        type: "timestamp",
        default: () => "CURRENT_TIMESTAMP(6)",
    })
    created_at: Date;

    @UpdateDateColumn({
        type: "timestamp",
        default: () => "CURRENT_TIMESTAMP(6)",
        onUpdate: "CURRENT_TIMESTAMP(6)",
    })
    updated_at: Date;
}
