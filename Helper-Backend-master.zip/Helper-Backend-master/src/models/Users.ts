import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
  ManyToOne,
  OneToMany,
  ManyToMany,
  JoinTable
} from "typeorm";
import Occurrences from "./Occurrences";
import Groups from "./Groups";
import Contracts from "./Contracts";
import Roles from "./Roles";

@Entity()
export default class Users {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable:false })
  name: string;

  @Column({ nullable: false, unique: true })
  email: string;

  @Column({ nullable: false})
  contact_number: string;

  @Column({nullable: false})
  password: string;

  @Column()
  confirm_password: string;

  @Column()
  status: number; //boolean

  @Column()
  last_login: Date;

  @ManyToOne( () => Contracts, contracts => contracts.id, {
    onDelete:"CASCADE"
  } )
  @JoinColumn({ name: "contract_id" })
  contract_id: Contracts;

  @ManyToOne( () => Groups, groups => groups.id, {
    onDelete:"CASCADE"
  } )
  @JoinColumn({ name: "group_id" })
  group_id: Groups; 

  @ManyToOne(() => Roles, roles => roles.id,  {
    onDelete:"CASCADE",
    eager: true
  })
   @JoinColumn()
  role_id: Roles;

  @OneToMany(() => Occurrences, occurrences => occurrences.id, {
    onDelete:"CASCADE"
  })
  occurrences: Occurrences[];

  
  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}

