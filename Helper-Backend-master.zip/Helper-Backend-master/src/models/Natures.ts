import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    OneToOne,
    JoinColumn,
    ManyToOne,
    OneToMany,
    ManyToMany,
} from "typeorm";
import ClassificationNature from "./ClassificationNature";
import Classifications from "./Classifications";

@Entity()
export default class Natures {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: true, unique: true })
    name: string;

    @OneToMany(
        () => ClassificationNature,
        (Classificationnature) => Classificationnature.id,
        {
            onDelete: "CASCADE",
        }
    )
    calssification_nature_id: ClassificationNature[];

    @ManyToOne(() => Classifications, (classifications) => classifications.id, {
        onDelete: "CASCADE",
        eager: true,
    })
    @JoinColumn()
    classification_id: Classifications;

    @CreateDateColumn({
        type: "timestamp",
        default: () => "CURRENT_TIMESTAMP(6)",
    })
    created_at: Date;

    @UpdateDateColumn({
        type: "timestamp",
        default: () => "CURRENT_TIMESTAMP(6)",
        onUpdate: "CURRENT_TIMESTAMP(6)",
    })
    updated_at: Date;
}
