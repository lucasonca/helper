import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  JoinColumn,
  OneToOne,
  ManyToOne,
  ManyToMany,
  JoinTable
} from "typeorm";
import ClassificationNature from "./ClassificationNature";
import Natures from "./Natures";
import Occurrences from "./Occurrences";

@Entity()
export default class Classifications {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar',{length:100, nullable: true, unique: true })
  name: string;

  @OneToMany(() => ClassificationNature, Classificationnature => Classificationnature.id,  {
    onDelete:"CASCADE",
  })
  calssification_nature_id: ClassificationNature[];

  @OneToMany(() => Natures, Natures => Natures.id,  {
    onDelete:"CASCADE",
  })
  nature_id: Natures[];
  

  @OneToMany(() => Occurrences, occurrences => occurrences.id,  {
    onDelete:"CASCADE"
  })
  occurrences: Occurrences[];
  
  @CreateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
  })
  created_at: Date;

  @UpdateDateColumn({
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP(6)",
    onUpdate: "CURRENT_TIMESTAMP(6)",
  })
  updated_at: Date;
}