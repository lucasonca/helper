import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    ManyToMany,
    JoinTable
  } from "typeorm";
import Permissions from "./Permissions";
  import Users from "./Users";
  
  @Entity()
  export default class Roles {
    @PrimaryGeneratedColumn()
    id: number;
  
    @Column({nullable: true})
    name: string;
  
    @OneToMany(() => Users, users => users.id,  {
      onDelete:"CASCADE"
    })
    users: Users[];

    @ManyToMany(() => Permissions, permissions => permissions.id,  {
      onDelete:"CASCADE",
      eager: true
    })
     @JoinTable(
    )
    permissions_id: Permissions[];
  
    @CreateDateColumn({
      type: "timestamp",
      default: () => "CURRENT_TIMESTAMP(6)",
    })
    created_at: Date;
  
    @UpdateDateColumn({
      type: "timestamp",
      default: () => "CURRENT_TIMESTAMP(6)",
      onUpdate: "CURRENT_TIMESTAMP(6)",
    })
    updated_at: Date;
  }
  