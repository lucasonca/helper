import models from "../models/init"
import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";


export default class HelpersRepository extends MasterRepository {
  constructor() {
    super(models.Helpers);
  }


  createHelpersCameras = async (data: any): Promise<Object> => {
    const repo_helpers = getRepository(this.model, "default");
    const repo_cameras = getRepository(models.Cameras, "default")
    const cameras = data.cameras;
    delete data.cameras;
    
    let result: any  = {};
    let result_cameras: any ={}
    try {
      result = await repo_helpers.save(data);
      cameras.map( (camera) =>{
        camera.helper_id = result.id
      }) 
      result_cameras = await repo_cameras.save(cameras)
      
    } catch (error) {
      return { created: false, error: error.message };
    }
    return { created: true, result:result, result_cameras:result_cameras };
    
 };

}

