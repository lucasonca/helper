import models from "../models/init"
import MasterRepository from "./master-repository";

export default class InstitutionTypeRepository extends MasterRepository {
  constructor() {
    super(models.InstitutionType);
  }
}
