import models from "../models/init"
import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";
import Classifications from "../models/Classifications";

export default class ClassificationNatureRepository extends MasterRepository {
  constructor() {
    super(models.ClassificationNature);
  }

}
