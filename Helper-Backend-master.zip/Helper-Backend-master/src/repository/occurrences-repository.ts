import models from "../models/init"
import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";

export default class OccurrencesRepository extends MasterRepository {
  constructor() {
    super(models.Occurrences);
  }

  readOccurrenceHelper = async(HelperID:any): Promise<Object> =>{
    const repo = getRepository(this.model,"default");
    const result = await repo.find({
      where:{
        helper:HelperID
      },
      relations:['helper']
    });
    return result;
  }

  createOccurrenceNature = async (data: any): Promise<Object> => {
    const repo_occurrence =getRepository(this.model, "default")
    const repo_nature = getRepository(models.Nature, "default")
    const nature = data.nature;
    delete data.nature
    let result: any  = {};
    let result_nature: any ={}
    try {
      result = await repo_occurrence.save(data);
      nature.occurrence = result.id;
      result_nature = await repo_nature.save(nature)
    } catch (error) {
      return { created: false, error: error.message };
    }
    return { created: true, result:result, result_nature:result_nature };
    
  }
}

  
 


