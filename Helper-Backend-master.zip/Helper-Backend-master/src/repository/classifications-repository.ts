import models from "../models/init"
import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";
import Classifications from "../models/Classifications";

export default class ClassificationsRepository extends MasterRepository {
  constructor() {
    super(models.Classifications);
  }

  readNatureClassification = async(date:any): Promise<Object> =>{
    
    const classification = await this.connection
    .getRepository(Classifications)
    .createQueryBuilder("classification")
    .leftJoinAndSelect("classification.natures", "nature")
    .getMany();
    
 
    return classification
   
}
}


