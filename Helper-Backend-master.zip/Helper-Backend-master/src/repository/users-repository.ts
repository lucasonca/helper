
import models from "../models/init"

import AuthenticableEntities from "./authenticable-entities";
// import MasterRepository from "./master-repository";

export default class UsersRepository extends AuthenticableEntities {
  constructor() {
    super(models.Users);
    this.relations = ["contract_id", "group_id"]
  }
}

