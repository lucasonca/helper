import models from "../models/init"
import MasterRepository from "./master-repository";

export default class NaturesRepository extends MasterRepository {
  constructor() {
    super(models.Natures);
  }
}
