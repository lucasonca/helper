import models from "../models/init"
import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";

export default class GroupsRepository extends MasterRepository {
  constructor() {
    super(models.Groups);
  }
}
