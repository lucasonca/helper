import models from "../models/init"
import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";

export default class InstitutionsRepository extends MasterRepository {
  constructor() {
    super(models.Institutions);    
  }

  readLocalization = async(InstitutionsID:any): Promise<Object> =>{
    
    const repo = getRepository(this.model, "default")
    const result = await repo.find({
      where:{
        id:InstitutionsID
      }
    }); 
    let latitude:any = 0;
    let longitude:any = 0;
    Object.keys(result).map(function(i) {
      latitude = result[i].latitude;
      longitude = result[i].longitude;
    });
    return {latitude, longitude};
   
}


createInstititionsCameras = async (data: any): Promise<Object> => {
  const repo_institutions = getRepository(this.model, "default");
  const repo_cameras = getRepository(models.Cameras, "default")
  const cameras = data.cameras;
  delete data.cameras;
  
  let result: any  = {};
  let result_cameras: any ={}
  try {
    result = await repo_institutions.save(data);
    cameras.map( (camera) =>{
      camera.institution_id = result.id
    }) 
    result_cameras = await repo_cameras.save(cameras)
  } catch (error) {
    return { created: false, error: error.message };
  }
  return { created: true, result:result, result_cameras:result_cameras };
  
};



}

