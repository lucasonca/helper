import { getRepository } from "typeorm";
import MasterRepository from "./master-repository";
import { compare } from "bcrypt";
import createNewToken from "../token/token-handler";
import models from "../models/init";
import Users from "../models/Users";

const moment = require("moment");
/**
  Classe com login comum para entidades autenticaveis
 */
export default class AuthenticableEntities extends MasterRepository {
  constructor(model) {
    super(model);
  }
  login = async (data: any): Promise<Object> => {
    let userRoles = "";

    const repo = getRepository(this.model, "default");

    const user: any = await repo.findOne({
      where: {
        email: data.email,
      },
      relations:['role_id']
    });
    

    Object.keys(user).map(function (role){
      userRoles = user[role].name;
    })
    
    
    if (user && (await compare(data.password, user.password))) {
      const token = await createNewToken({
        userID: user.id,
      });
      const date = moment().format();
      const save_data = {
        id: user.id,
        last_login: date,
      };
      user.last_login = date;
      await repo.save(save_data);
      const retorno = { auth: true, token: token, user: user, roles:userRoles};
      return retorno;
    } else return false;
  };
}
