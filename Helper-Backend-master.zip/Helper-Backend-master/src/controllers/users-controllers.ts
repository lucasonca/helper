import repositories from "../repository/init";
import AuthenticableControllers from "./authenticable-controllers";
// import MasterController from "./master-controllers";

export default class UsersController extends AuthenticableControllers {
  constructor() {
    super(new repositories.UsersRepository());
    this.request_fields = [
      "name",
      "email",
      "contact_number",
      "password",
    ];
  }
}
