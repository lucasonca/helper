import repositories from "../repository/init";
import MasterController from "./master-controllers";

export default class RolesController extends MasterController {
  constructor() {
    super(new repositories.RolesRepository());
  }
}