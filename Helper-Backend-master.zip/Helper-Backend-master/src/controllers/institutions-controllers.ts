import repositories from "../repository/init";

import MasterController from "./master-controllers";

export default class InstitutionsController extends MasterController {
  constructor() {
    super(new repositories.InstitutionsRepository());
  }

  readLocalizationMaps = async (req, res) => {
    const query_result = await this.repository.readLocalization(
      req.params.id
    )
    if(!query_result) return res.status(500).json(query_result)
    
    return res.status(200).json(query_result)
  }


  cadastrarInstitutionsCameras = async (req, res) => {
    const query_result = await this.repository.createInstititionsCameras(
      req.body
    )
    if(!query_result) return res.status(500).json(query_result)
    
    return res.status(200).json(query_result)
  }


}
