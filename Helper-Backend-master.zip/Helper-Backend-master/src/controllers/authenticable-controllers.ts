import MasterController from "./master-controllers";
import { hash } from "bcrypt";

export default class AuthenticableControllers extends MasterController {
  constructor(repository) {
    super(repository);
  }

  create = async (req, res): Promise<any> => {
    if (Object.keys(req.body).length === 0)
      return res
        .status(400)
        .json({ message: "Todos os campos devem ser preenchidos." });
    if (!this.validator(req.body, this.request_fields))
      return res
        .status(400)
        .json({ message: "Todos os campos devem ser preenchidos." });
    if (req.body.password != req.body.confirm_password)
      return res.status(400).json({
        created: false,
        message: "O campo password e o campo confirmar password devem ser iguais.",
      });

    req.body.password = await hash(req.body.password, 10);

    const new_user = await this.repository.create(req.body);

    if (!new_user) return res.status(500).json(new_user);

    res.status(200).json(new_user);
  };

  login = async (req, res): Promise<any> => {
     if (Object.keys(req.body).length === 0)
      return res
        .status(400)
        .json({ message: "Todos os campos devem ser preenchidos." });

    const retorno = await this.repository.login(req.body);

    if (!retorno) {
      return res
        .status(200)
        .json({ auth: false, message: "User/Password incorrect(s)." });
    }

    res
      .status(200)
      .json({ auth: true, token: retorno.token, roles: retorno.roles, user: retorno.user});
  };

  update = async (req, res) => {
    if(req.body.password) {
      req.body.password = await hash(req.body.password, 10)
    }
    const updated_data: any = await this.repository.update(req.params.id, req.body);
    if (!updated_data.updated) return res.status(500).json(updated_data);

    return res.status(200).json(updated_data);
  };
}

//   create = async (req, res): Promise<Response> => {
//     // if (req.body.password != req.body.confpassword)
//     //   return res.status(400).json({
//     //     created: false,
//     //     message: "O campo password e o campo confirmar password devem ser iguais.",
//     //   });

//     if (Object.keys(req.body).length === 0)
//       return res
//         .status(400)
//         .json({ message: "Todos os campos devem ser preenchidos." });
//     if (!this.validator(req.body, this.request_fields))
//       return res
//         .status(400)
//         .json({ message: "Todos os campos devem ser preenchidos." });

//     req.body.password = await hash(req.body.password, 10);

//     const new_user = await this.repository.create(req.body);

//     if (!new_user) return res.status(500).json(new_user);

//     res.status(200).json(new_user);
//   };

//   login = async (req, res): Promise<Response> => {
//     const retorno = await this.repository.login(req.body);

//     if (!retorno) {
//       return res
//         .status(200)
//         .json({ auth: false, message: "User/Password incorrect(s)." });
//     }

//     res
//       .status(200)
//       .json({ auth: true, token: retorno.token, user: retorno.user });
//   };

