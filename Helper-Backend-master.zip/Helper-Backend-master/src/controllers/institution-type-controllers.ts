import repositories from "../repository/init";
import MasterController from "./master-controllers";

export default class InstitutionTypeController extends MasterController {
  constructor() {
    super(new repositories.InstitutionTypeRepository());
  }
}
