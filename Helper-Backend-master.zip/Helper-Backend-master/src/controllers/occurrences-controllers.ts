import repositories from "../repository/init";

import MasterController from "./master-controllers";

export default class OccurrencesController extends MasterController {
  constructor() {
    super(new repositories.OccurrencesRepository());
  }

  filtrarOccurrenceHelper = async (req,res) => {
    const query_result = await this.repository.readOccurrenceHelper(
      req.params.id
    )

    if(!query_result) return res.status(500).json(query_result)

    return res.status(200).json(query_result)
  }

  readOccurrence = async (req, res) => {
    const query_result = await this.repository.readOccurrenceNature(
      req.params.id
    )
    if(!query_result) return res.status(500).json(query_result)
    
    return res.status(200).json(query_result)
  }
}
