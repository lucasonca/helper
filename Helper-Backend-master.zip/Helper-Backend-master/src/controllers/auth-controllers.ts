const token_handler = require('../token/token-handler')
export default class AuthControllers {
  validateToken = async (req, res) => {
    const token = req.headers["authorization"];
    if(!token) return res.status(401).json({message:'Token não fornecido.'})

    let data_token = token_handler.verifyToken(token.split(" ")[1])
    if(!data_token) return res.status(200).json({auth:false})

    res.status(200).json({auth:true});
  };
}