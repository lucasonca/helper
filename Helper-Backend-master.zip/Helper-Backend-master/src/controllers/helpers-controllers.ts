import repositories from "../repository/init";

import MasterController from "./master-controllers";

export default class HelpersController extends MasterController {
  constructor() {
    super(new repositories.HelpersRepository());
  }

  cadastrarHelpersCameras = async (req, res) => {
    const query_result = await this.repository.createHelpersCameras(
      req.body
    )
    if(!query_result) return res.status(500).json(query_result)
    
    return res.status(200).json(query_result)
  }

}
