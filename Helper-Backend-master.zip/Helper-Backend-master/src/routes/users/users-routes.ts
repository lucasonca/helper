import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class UsersRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.UsersController());

    this.endpoint = "/users";

    this.endpoints["login"] = {
      login: {
        endpoint: this.router.post("/login", this.controller.login),
      },
    };
  }
  
}
