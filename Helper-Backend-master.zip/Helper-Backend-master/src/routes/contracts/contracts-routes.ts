import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class ContractsRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.ContractsController());

    this.endpoint = "/contracts";
  }
}
