import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class RolesRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.RolesController());

    this.endpoint = "/roles";
  }
  
}