import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class ClassificationNatureRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.ClassificationNatureController());

    this.endpoint = "/classification-nature";
  }
}
