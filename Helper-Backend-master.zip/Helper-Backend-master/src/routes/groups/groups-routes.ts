import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class GroupsRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.GroupsController());

    this.endpoint = "/groups";
  }
}
