import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class OccurrencesRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.OccurrencesController());

    this.endpoint = "/occurrences";

    this.endpoints["filtrar-occurrence-helper"] = {
      filtro_occurrence_helper: {
        endpoint: this.router.get("/filtrar-occurrence-helper", this.controller.filtrarOccurrenceHelper),
      },
    };

    this.endpoints["read-occurrence"] = {
      read_occurrence: {
        endpoint: this.router.get("/read-occurrence", this.controller.readOccurrence),
      },
    };
  }
}
