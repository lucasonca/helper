import controllers from "../controllers/init";
import MasterRoutes from "./master-routes";
import * as multer from 'multer'
import { multerConfig } from "../middlewares/multerUpload";
import { Request, Response } from "express";

export default class UploadRoutes extends MasterRoutes {
  constructor(controller: any) {
    super(controller);

     this.endpoints["upload"] = {
      upload: {
        endpoint: this.router.post("/upload", multer(multerConfig).single('file'), this.controller.upload),
      },
    };

    // this.endpoints["login"] = {
    // upload:{
    //   endpoint: this.router.post( "/upload", multer(multerConfig).single('file'), (request: Request, response: Response) => {
    //     return response.json({ message: 'Imagem enviada' })
    //   }
    // }
  }
}
