import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class ClassificationsRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.ClassificationsController());

    this.endpoint = "/classifications";
  }
}
