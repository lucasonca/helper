import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class NaturesRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.NaturesController());

    this.endpoint = "/natures";
  }
}
