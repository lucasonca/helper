import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class PermissionsRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.PermissionsController());

    this.endpoint = "/permissions";
  }
  
}
