import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class HelpersRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.HelpersController());

    this.endpoint = "/helpers";



    this.endpoints["helper-cameras"] = {
      helper_cameras: {
        endpoint: this.router.post("/helper-cameras", this.controller.cadastrarHelpersCameras),
      },

     }
  }
  
}
