import controllers from "../../controllers/init";
import MasterRoutes from "../master-routes";

export default class InstitutionsRoutes extends MasterRoutes {
  endpoint: string;
  constructor() {
    super(new controllers.InstitutionsController());

    this.endpoint = "/institutions";

    this.endpoints["institutions-maps"] = {
      institutions_maps: {
        endpoint: this.router.get("/institutions-maps/:id", this.controller.readLocalizationMaps),
      },

     }

     this.endpoints["institutions-cameras"] = {
      institutions_cameras: {
        endpoint: this.router.post("/institution-cameras", this.controller.cadastrarInstitutionsCameras),
      },

     }


  }
}
