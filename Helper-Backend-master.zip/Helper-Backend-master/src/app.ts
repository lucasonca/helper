import * as express from "express";
import { json } from "body-parser";
import * as cors from "cors";
import * as path from "path";
import * as ejs from "ejs";

import routes from "./routes/routes";

const app = express();

app.use(cors());
app.use(json());

app.use(express.static(path.join(__dirname, "../public")));
app.set("views", path.join(__dirname, "../public"));
app.engine("html", ejs.renderFile);
app.set("view engine", "html");

app.use(express.static(path.join(__dirname, "../../helper-front-end/build")));

// * Alunos files
app.use(
    "/files/alunos/perfil",
    express.static(path.join(__dirname, "../public/uploads/alunos/perfil"))
);

Object.keys(routes).forEach((route) =>
    app.use(routes[route]["endpoint"], routes[route]["router"])
);

export default app;
